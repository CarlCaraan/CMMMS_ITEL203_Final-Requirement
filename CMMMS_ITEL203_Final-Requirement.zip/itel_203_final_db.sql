-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2021 at 11:29 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itel_203_final_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `birthcert`
--

CREATE TABLE `birthcert` (
  `id` int(11) NOT NULL,
  `req` varchar(25) NOT NULL,
  `copies` char(10) NOT NULL,
  `others` char(10) NOT NULL,
  `brn` char(25) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(45) NOT NULL,
  `prov` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `lnamef` varchar(25) NOT NULL,
  `fnamef` varchar(25) NOT NULL,
  `mnamef` varchar(25) NOT NULL,
  `lnamem` varchar(20) NOT NULL,
  `fnamem` varchar(20) NOT NULL,
  `mnamem` varchar(20) NOT NULL,
  `late` char(20) NOT NULL,
  `when1` date NOT NULL,
  `tin` char(25) NOT NULL,
  `tn` char(25) NOT NULL,
  `extra` varchar(25) NOT NULL,
  `specou` varchar(25) NOT NULL,
  `rfull` varchar(45) NOT NULL,
  `madd` varchar(45) NOT NULL,
  `mcity` varchar(25) NOT NULL,
  `mprov` varchar(25) NOT NULL,
  `mpho` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `id` int(11) NOT NULL,
  `tin` int(45) NOT NULL,
  `rdo` int(45) NOT NULL,
  `name` varchar(40) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `phone` char(12) NOT NULL,
  `taxpayer` char(12) NOT NULL,
  `pcic` varchar(45) NOT NULL,
  `pname` varchar(45) NOT NULL,
  `plocation` varchar(45) NOT NULL,
  `pnumber` varchar(45) NOT NULL,
  `dawarded` date NOT NULL,
  `dcompleted` date NOT NULL,
  `dacp` date NOT NULL,
  `dccp` date NOT NULL,
  `dapbc` date NOT NULL,
  `dcpbc` date NOT NULL,
  `davat` date NOT NULL,
  `dcvat` date NOT NULL,
  `dacwt` date NOT NULL,
  `dccwt` date NOT NULL,
  `datapt` date NOT NULL,
  `dctapt` date NOT NULL,
  `dacfp` date NOT NULL,
  `dccfp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iskoched`
--

CREATE TABLE `iskoched` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `city` varchar(20) NOT NULL,
  `prov` varchar(20) NOT NULL,
  `gender` char(10) NOT NULL,
  `cs` char(15) NOT NULL,
  `czs` varchar(20) NOT NULL,
  `mpho` char(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `schoolsec` varchar(25) NOT NULL,
  `hag` varchar(20) NOT NULL,
  `pa` varchar(20) NOT NULL,
  `padd` varchar(45) NOT NULL,
  `zc` char(25) NOT NULL,
  `sa` varchar(25) NOT NULL,
  `tod` varchar(25) NOT NULL,
  `ipa` varchar(25) NOT NULL,
  `occ` varchar(25) NOT NULL,
  `ea` varchar(25) NOT NULL,
  `noe` varchar(25) NOT NULL,
  `hea` varchar(25) NOT NULL,
  `tp` char(25) NOT NULL,
  `sif` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iskolaguna`
--

CREATE TABLE `iskolaguna` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `slot` int(11) NOT NULL,
  `age` int(10) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `status` varchar(15) NOT NULL,
  `religion` varchar(45) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(45) NOT NULL,
  `resadd` varchar(45) NOT NULL,
  `prov` varchar(45) NOT NULL,
  `mun` varchar(45) NOT NULL,
  `brgy` varchar(45) NOT NULL,
  `cel` char(20) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fat` varchar(45) NOT NULL,
  `oc1` varchar(45) NOT NULL,
  `inc1` char(25) NOT NULL,
  `mot` varchar(45) NOT NULL,
  `oc2` varchar(45) NOT NULL,
  `inc2` char(25) NOT NULL,
  `gua` varchar(45) NOT NULL,
  `rel` varchar(45) NOT NULL,
  `inc3` char(25) NOT NULL,
  `cel1` char(25) NOT NULL,
  `afgi` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `postal`
--

CREATE TABLE `postal` (
  `id` int(11) NOT NULL,
  `pid` char(25) NOT NULL,
  `rev` date NOT NULL,
  `acn` char(15) NOT NULL,
  `poc` char(25) NOT NULL,
  `pon` varchar(45) NOT NULL,
  `orno` char(25) NOT NULL,
  `ordate` date NOT NULL,
  `prn` varchar(25) NOT NULL,
  `purpose` char(25) NOT NULL,
  `optional` varchar(35) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `suffix` varchar(45) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(45) NOT NULL,
  `prov` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` char(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(62, 'admin', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `birthcert`
--
ALTER TABLE `birthcert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iskoched`
--
ALTER TABLE `iskoched`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iskolaguna`
--
ALTER TABLE `iskolaguna`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `postal`
--
ALTER TABLE `postal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `birthcert`
--
ALTER TABLE `birthcert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `iskoched`
--
ALTER TABLE `iskoched`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `iskolaguna`
--
ALTER TABLE `iskolaguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `postal`
--
ALTER TABLE `postal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
