<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Application for Ched Scholarship Program (CSP)</title>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="css/g_form5.css?v=<?php echo time(); ?>">
</head>
<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=date], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=number], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=email], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=tel], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>
<body>

<?php
include_once 'header2.php';
?>
<!--continuation-->
                    <a href='g_form4.php' class="button" id="login-page"><i class="material-icons">&#xe5cb;</i>previous</a>
                </li>
                <li class="navbar__btn">
                    <a href='g_form1.php' class="button" id="login-page"><i class="material-icons">&#xe409;</i>next</a>
                </li>
                <li class="navbar__btn">
                    <a href='crud_g_form5.php' class="button" id="login-page"><i class="fas fa-database" style="margin-right:2px"></i>manage</a>
                </li>
            </ul>
        </div>
    </nav>
<br>
<?php
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$lname=$_POST['lname'];
	$dob=$_POST['dob'];
	$city=$_POST['city'];
	$prov=$_POST['prov'];
	$gender=$_POST['gender'];
	$cs=$_POST['cs'];
	$czs=$_POST['czs'];
	$mpho=$_POST['mpho'];
	$email=$_POST['email'];
	$schoolsec=$_POST['schoolsec'];
	$hag=$_POST['hag'];
	$pa=$_POST['pa'];
	$padd=$_POST['padd'];
	$zc=$_POST['zc'];
	$sa=$_POST['sa'];
	$tod=$_POST['tod'];
	$ipa=$_POST['ipa'];
	$occ=$_POST['occ'];
	$ea=$_POST['ea'];
	$noe=$_POST['noe'];
	$hea=$_POST['hea'];
	$tp=$_POST['tp'];
	$sif=$_POST['sif'];
	$sql = "INSERT INTO iskoched(fname,mname,lname,dob,city,prov,gender,cs,czs,mpho,email,schoolsec,hag,pa,padd,zc,sa,tod,ipa,occ,ea,noe,hea,tp,sif)VALUES('$fname','$mname','$lname','$dob','$city','$prov','$gender','$cs','$czs','$mpho','$email','$schoolsec','$hag','$pa','$padd','$zc','$sa','$tod','$ipa','$occ','$ea','$noe','$hea','$tp','$sif')";
		$result = mysqli_query($conn, $sql);
	echo "<script>alert('Wow! User Registration Completed.')</script>";
}

 ?>

  <!--Header-->
  <div class="form__container">
      <div class="upper__container">
        <div class="upper__logo1">
          <img src="img\logo5.png" style="width: 80px; height: 80px;">
        </div>
        <div class="upper__header">
          <p style="font-family:sans-serif; text-align:center"> <b>Office of the President of the Philippines <br>
              COMMISSION ON HIGHER EDUCATION <br>
              REGIONAL OFFICE ____</b></p>
          <p style="text-align: center; font-family:sans-serif">
            <b style="font-size: 20px">CHED SCHOLARSHIP PROGRAM</b> <br>
            <b style="font-size: 17px">APPLICATION FORM</b>
          </p>
        </div>
        <div class="upper__logo2">
          <img src="img\logo6.png" style="width: 150px; height: 150px;">
        </div>

  </div>
  <br><br>
  <!--about-->
  <div class="about__container">
      <p style="text-align: center; padding-top: 40px">
        Instructions: Read General and Documentary Requirements.
        Fill in all the required information. Do not leave an item blank.
         If item is not applicable, indicate "N/A".</p>
  </div>

  <div class="about2__container">
<h3>Application period: March 1 to May 31 of the current academic year</h3>
  </div>
  <!--2fr-->
<div class="twofr--about__container">
  <!--card-->
  <div class="about__card1">
    <b>CRITERIA OF ELIGIBILITY per CMO 08 s. 2019</b> <br>
    1. Filipino citizen; <br>
    2. Graduating high school students/High school graduate. <br>
    3. General Weighted Average (GWA) of at least 90% or above. <br>
    4. Combined annual gross income of parents/guardian not to <br>
    exceed Four Hundred Thousand Pesos (PhP400,000.00) or <br>
    solo parent/guardian whose annual gross income does not <br>
    exceed the said amount; <br>
    In highly exceptional cases where income exceeds <br>
Php400,000.00, the CHEDRO StuFAPs Committee shall <br>
determine the merits of the application <br>
5. Avail of only one government funded financial assistance <br>
program <br>

  </div>
  <div class="about__card2">
<b>DOCUMENTARY REQUIREMENTS per CMO 08 s. 2019</b> <br>
<b>Academic Requirements</b>- any one of the following: <br>
(  )  1. High school report card <br>
(  )  2. Duly certified true copy of grades for Grade 11 or 1st semester of Grade 12 for <br>
<u>graduating high school students</u>
<b>Income Requirements</b> - any one of the following: <br>
(  )  1. Latest ITR of parents or guardian if employed <br>
(  )  2. Certificate of Tax Exemption from the BIR <br>
 (  )  3. Certificate of Indigency from their Barangay <br>
 (  )  4. Certificate/Case Study from DSWD <br>
 (  )  5. Latest copy of contract or proof of income for children of Overseas Filipino <br>
Workers (OFW) and seafarers.
  </div>
</div>
<hr>
<b>NOTE: Beneficiaries of free higher education under RA 10931 can only receive stipend under this program</b>
<hr>
<p style="text-align: center; background-color: gray; padding: 15px"><b>PERSONAL INFORMATION</b></p>
<hr>
<!--Form-->
<form method="post">
<b>1. Name</b> <br>
				First Name:<input type="text" name="fname" size="30"placeholder="   First Name"required> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
				Middle Name:<input type="text" name="mname" size="30"placeholder="   Middle Name"required> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
				Last Name:<input type="text" name="lname" size="30"placeholder="   Last Name"required><br>
        <hr>

<b>2. Date of Birth</b> <br>
				<input type="date" name="dob" placholder ="" size ="50"required>
        <hr>

<b>3. Place of Birth</b> <br>
				Municipality:<input type="text" name="city" size="10"placeholder="   Municipality"required>
				Province:<input type="text" name="prov" size="10"placeholder="   Province"required><br>
        <hr>
<b>4. Sex</b> <br>
<input type="radio" id="Male" name="gender" value="Male">
  <label for="Male">Male</label>
  <input type="radio" id="Female" name="gender" value="Female">
  <label for="Female">Female</label>
        <hr>

<b>5. Civil Status</b> <br>
				<input type="radio" name="cs" value="Single">Single &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="radio" name="cs" value="Married">Married &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="radio" name="cs" value="Annulled">Annulled &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="radio" name="cs" value="Windowed">Windowed &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="radio" name="cs" value="Separated">Separated &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="radio" name="cs" value="Others">Others &nbsp &nbsp &nbsp &nbsp &nbsp
        <hr>
<b>6. Citizenship</b>
				<input type="text" name="czs" size="30"placeholder="   Specify"required><br>
        <hr>
<b>7. Mobile Number</b>
        <input type="tel"  name="mpho" size="30" placeholder="   912-345-6789"pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
        <br>
        <hr>

<b>8. Email-Address</b>
				<input type="email" name="email" size="30"placeholder="   email"required><br>
        <hr>
<b>9. School Sector</b>

				<input type="text" name="schoolsec" size="30"placeholder=""required><br>
<hr>
<b>10. Highest Attained Grade/Year Level</b>

				<input type="text" name="hag" size="30"placeholder="   Grade/Year Level"required><br>
<hr>
<b>11. Present Address</b>

				<input type="text" name="pa" size="30"placeholder="   City/Municipality/Province"required><br>
<hr>
<b>12. Permanent Address</b>

				<input type="text" name="padd" size="30"placeholder="   City/Municipality/Province"required><br>
<hr>
<b>13. Zip Code</b>

				<input type="text" name="zc" size="30"placeholder="   Zip Code"required><br>
<hr>
<b>14. School Address</b>

				<input type="text" name="sa" size="30"placeholder="   City/Municipality/Province"required><br>
<hr>
<b>15. Type of Disability</b>

				<input type="text" name="tod" size="30"placeholder="   N/A if not applicable"><br>
<hr>
<b>16. IP Affiliation</b>

				<input type="number" name="ipa" size="30"placeholder="   Specify"><br>
<hr>
<b>17. Occupation</b>

				<input type="text" name="occ" size="30"placeholder="   N/A if not applicable"><br>
<hr>
<b>18. Employer Address</b>

				<input type="text" name="ea" size="30"placeholder="   City/Municipality/Province"required><br>
<hr>
<b>19. Name of Employer</b>

				<input type="text" name="noe" size="30"placeholder="   First Name, MI, Last Name"required><br>
<hr>
<b>20. Hightest Educational Attainment</b>

				<input type="text" name="hea" size="30"placeholder="   Grade/Year Level"required><br>
<hr>
<b>21. Total Parents Taxable Income</b>

				<input type="number" name="tp" size="30"placeholder=""required><br>
<hr>
<b>22. No. of Siblings in the Family</b>

				<input type="number" name="sif" size="30"placeholder=""><br>
<hr>
<!--reset submit-->
      <div class="savereset__container" style="align-items: center; justify-content: center; text-align:center; padding-bottom: 4rem; padding-top: 4rem">
				<input type="submit" name="submit" value="SUBMIT">
				<input type="Reset" name="clear" Value="RESET">
			</div>
      </div>
</form>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>

</html>
