<!-- Add user -->
	$(document).on('click','#btn-add',function(e) {
		var data = $("#user_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form4.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#addEmployeeModal').modal('hide');
						alert('Data added successfully !');
                        location.reload();
					} else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on('click','.update',function(e) {
		var id=$(this).attr("data-id");
		var req=$(this).attr("data-req");
		var copies=$(this).attr("data-copies");
		var others=$(this).attr("data-others");
		var brn=$(this).attr("data-brn");
		var gender=$(this).attr("data-gender");
		var lname=$(this).attr("data-lname");
		var fname=$(this).attr("data-fname");
		var mname=$(this).attr("data-mname");
		var dob=$(this).attr("data-dob");
		var pob=$(this).attr("data-pob");
		var prov=$(this).attr("data-prov");
		var country=$(this).attr("data-country");
		var lnamef=$(this).attr("data-lnamef");
		var fnamef=$(this).attr("data-fnamef");
		var mnamef=$(this).attr("data-mnamef");
		var lnamem=$(this).attr("data-lnamem");
		var fnamem=$(this).attr("data-fnamem");
		var mnamem=$(this).attr("data-mnamem");
		var late=$(this).attr("data-late");
		var when1=$(this).attr("data-when1");
		var tin=$(this).attr("data-tin");
		var tn=$(this).attr("data-tn");
		var extra=$(this).attr("data-extra");
		var specou=$(this).attr("data-specou");
		var rfull=$(this).attr("data-rfull");
		var madd=$(this).attr("data-madd");
		var mcity=$(this).attr("data-mcity");
		var mprov=$(this).attr("data-mprov");
		var mpho=$(this).attr("data-mpho");
		$('#id_u').val(id);
		$('#req_u').val(req);
		$('#copies_u').val(copies);
		$('#others_u').val(others);
		$('#brn_u').val(brn);
		$('#gender_u').val(gender);
		$('#lname_u').val(lname);
		$('#fname_u').val(fname);
		$('#mname_u').val(mname);
		$('#dob_u').val(dob);
		$('#pob_u').val(pob);
		$('#prov_u').val(prov);
		$('#country_u').val(country);
		$('#lnamef_u').val(lnamef);
		$('#fnamef_u').val(fnamef);
		$('#mnamef_u').val(mnamef);
		$('#lnamem_u').val(lnamem);
		$('#fnamem_u').val(fnamem);
		$('#mnamem_u').val(mnamem);
		$('#late_u').val(late);
		$('#when1_u').val(when1);
		$('#tin_u').val(tin);
		$('#tn_u').val(tn);
		$('#extra_u').val(extra);
		$('#specou_u').val(specou);
		$('#rfull_u').val(rfull);
		$('#madd_u').val(madd);
		$('#mcity_u').val(mcity);
		$('#mprov_u').val(mprov);
		$('#mpho_u').val(mpho);
	});
<!-- Update -->
	$(document).on('click','#update',function(e) {
		var data = $("#update_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form4.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#editEmployeeModal').modal('hide');
						alert('Data updated successfully !');
                        location.reload();
					}
					else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on("click", ".delete", function() {
		var id=$(this).attr("data-id");
		$('#id_d').val(id);

	});
	$(document).on("click", "#delete", function() {
		$.ajax({
			url: "backend/crud_g_form4.php",
			type: "POST",
			cache: false,
			data:{
				type:3,
				id: $("#id_d").val()
			},
			success: function(dataResult){
					$('#deleteEmployeeModal').modal('hide');
					$("#"+dataResult).remove();

			}
		});
	});
	$(document).on("click", "#delete_multiple", function() {
		var user = [];
		$(".user_checkbox:checked").each(function() {
			user.push($(this).data('user-id'));
		});
		if(user.length <=0) {
			alert("Please select records.");
		}
		else {
			WRN_PROFILE_DELETE = "Are you sure you want to delete "+(user.length>1?"these":"this")+" row?";
			var checked = confirm(WRN_PROFILE_DELETE);
			if(checked == true) {
				var selected_values = user.join(",");
				console.log(selected_values);
				$.ajax({
					type: "POST",
					url: "backend/crud_g_form4.php",
					cache:false,
					data:{
						type: 4,
						id : selected_values
					},
					success: function(response) {
						var ids = response.split(",");
						for (var i=0; i < ids.length; i++ ) {
							$("#"+ids[i]).remove();
						}
					}
				});
			}
		}
	});
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		var checkbox = $('table tbody input[type="checkbox"]');
		$("#selectAll").click(function(){
			if(this.checked){
				checkbox.each(function(){
					this.checked = true;
				});
			} else{
				checkbox.each(function(){
					this.checked = false;
				});
			}
		});
		checkbox.click(function(){
			if(!this.checked){
				$("#selectAll").prop("checked", false);
			}
		});
	});
