<?php
include 'backend/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manage - Application For Scholarship Of Laguna</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/crud_user.css?v=<?php echo time(); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="ajax/ajax2.js"></script>
</head>

<body>

		<!--table-->
    <div class="container">
	<p id="success"></p>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Records</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="logout.php" type="button" class="btn btn-danger" id="logout_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe9ba;</i>Logout</a>
						<a href="g_form2.php" type="button" class="btn btn-danger" id="back_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe85d;</i>back</a>
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xe7fe;</i> <span>Add Records</span></a>
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons">&#xef66;</i> <span>Delete</span></a>
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th>
						<th>ID</th>
                        <th>Taxpayer Identification Number (TIN)</th>
                        <th>RDO</th>
                        <th>Name of Taxpayer/Contractor</th>
												<th>ZIP Code</th>
                        <th>Contact Number (+63)</th>
												<th>Taxpayer Classification:</th>
                        <th>PSIC</th>
                        <th>Project Name</th>
												<th>Project Location</th>
												<th>Project ID Number</th>
                        <th>Date Awarded</th>
												<th>Date Completed</th>
                        <th>Date Awarded Contract Price</th>
                        <th>Date Completed Contract Price</th>
                        <th>Date Awarded Progress Billings Collected</th>
                        <th>Date Completed_Progress Billings Collected</th>
                        <th>Date Awarded VAT</th>
                        <th>Date Completed VAT</th>
                        <th>Date Awarded Creditable Withholding Tax</th>
                        <th>Date Completed Creditable Withholding Tax</th>
                        <th>Date Awarded Total Amount Collected</th>
                        <th>Date Completed Total Amount Collected</th>
                        <th>Date Awarded Collectible Final Payment</th>
                        <th>Date Completed Collectible Final Payment</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
				<tbody>

				<?php
				$result = mysqli_query($conn,"SELECT * FROM contract");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					<td><?php echo $i; ?></td>
					<td><?php echo $row["tin"]; ?></td>
					<td><?php echo $row["rdo"]; ?></td>
					<td><?php echo $row["name"]; ?></td>
					<td><?php echo $row["zip"]; ?></td>
					<td><?php echo $row["phone"]; ?></td>
					<td><?php echo $row["taxpayer"]; ?></td>
					<td><?php echo $row["pcic"]; ?></td>
					<td><?php echo $row["pname"]; ?></td>
					<td><?php echo $row["plocation"]; ?></td>
					<td><?php echo $row["pnumber"]; ?></td>
					<td><?php echo $row["dawarded"]; ?></td>
					<td><?php echo $row["dcompleted"]; ?></td>
					<td><?php echo $row["dacp"]; ?></td>
					<td><?php echo $row["dccp"]; ?></td>
					<td><?php echo $row["dapbc"]; ?></td>
					<td><?php echo $row["dcpbc"]; ?></td>
					<td><?php echo $row["davat"]; ?></td>
					<td><?php echo $row["dcvat"]; ?></td>
					<td><?php echo $row["dacwt"]; ?></td>
					<td><?php echo $row["dccwt"]; ?></td>
					<td><?php echo $row["datapt"]; ?></td>
					<td><?php echo $row["dctapt"]; ?></td>
					<td><?php echo $row["dacfp"]; ?></td>
					<td><?php echo $row["dccfp"]; ?></td>
					<td>
						<a href="#editEmployeeModal" class="edit" data-toggle="modal">
							<i class="material-icons update" data-toggle="tooltip"
							data-id="<?php echo $row["id"]; ?>"
							data-tin="<?php echo $row["tin"]; ?>"
							data-rdo="<?php echo $row["rdo"]; ?>"
							data-name="<?php echo $row["name"]; ?>"
							data-zip="<?php echo $row["zip"]; ?>"
							data-phone="<?php echo $row["phone"]; ?>"
							data-taxpayer="<?php echo $row["taxpayer"]; ?>"
							data-pcic="<?php echo $row["pcic"]; ?>"
							data-pname="<?php echo $row["pname"]; ?>"
							data-plocation="<?php echo $row["plocation"]; ?>"
							data-pnumber="<?php echo $row["pnumber"]; ?>"
							data-dawarded="<?php echo $row["dawarded"]; ?>"
							data-dcompleted="<?php echo $row["dcompleted"]; ?>"
							data-dacp="<?php echo $row["dacp"]; ?>"
							data-dccp="<?php echo $row["dccp"]; ?>"
							data-dapbc="<?php echo $row["dapbc"]; ?>"
							data-dcpbc="<?php echo $row["dcpbc"]; ?>"
							data-davat="<?php echo $row["davat"]; ?>"
							data-dcvat="<?php echo $row["dcvat"]; ?>"
							data-dacwt="<?php echo $row["dacwt"]; ?>"
							data-dccwt="<?php echo $row["dccwt"]; ?>"
							data-datapt="<?php echo $row["datapt"]; ?>"
							data-dctapt="<?php echo $row["dctapt"]; ?>"
							data-dacfp="<?php echo $row["dacfp"]; ?>"
							data-dccfp="<?php echo $row["dccfp"]; ?>"
							title="Edit">&#xE254;</i>
						</a>
						<a href="#deleteEmployeeModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
						 title="Delete">&#xE872;</i></a>
                    </td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>

        </div>
    </div>
	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form">
					<div class="modal-header">
						<h4 class="modal-title">Add Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>Taxpayer Identification Number (TIN)</label>
							<input type="text" id="tin" name="tin" class="form-control" required>
						</div>
						<div class="form-group">
							<label>RDO</label>
							<input type="text" id="rdo" name="rdo" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name of Taxpayer/Contractor</label>
							<input type="text" id="name" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>ZIP Code</label>
							<input type="text" id="zip" name="zip" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Contact Number (+63)</label>
							<input type="tel" id="phone" name="phone" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Taxpayer Classification:</label>
				<select name="taxpayer" id="taxpayer"class="form-control"required>
            <option value="Individual">Individual</option>
            <option value="Corporation">Corporation</option>
        </select>
						</div>
						<div class="form-group">
							<label>PSIC</label>
							<input type="text" id="pcic" name="pcic" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project Name</label>
							<input type="text" id="pname" name="pname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project Location</label>
							<input type="text" id="plocation" name="plocation" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project ID Number</label>
							<input type="text" id="pnumber" name="pnumber" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded</label>
							<input type="date" id="dawarded" name="dawarded" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed</label>
							<input type="date" id="dcompleted" name="dcompleted" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded Contract Price</label>
							<input type="date" id="dacp" name="dacp" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Date Completed Contract Price</label>
							<input type="date" id="dccp" name="dccp" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded Progress Billings Collected</label>
							<input type="date" id="dapbc" name="dapbc" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed_Progress Billings Collected</label>
							<input type="date" id="dcpbc" name="dcpbc" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded VAT</label>
							<input type="date" id="davat" name="davat" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed VAT</label>
							<input type="date" id="dcvat" name="dcvat" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded Creditable Withholding Tax</label>
							<input type="date" id="dacwt" name="dacwt" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed Creditable Withholding Tax</label>
							<input type="date" id="dccwt" name="dccwt" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Awarded Total Amount Collected</label>
							<input type="date" id="datapt" name="datapt" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Completed Total Amount Collected</label>
							<input type="date" id="dctapt" name="dctapt" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded Collectible Final Payment</label>
							<input type="date" id="dacfp" name="dacfp" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Completed Collectible Final Payment</label>
							<input type="date" id="dccfp" name="dccfp" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="update_form">
					<div class="modal-header">
						<h4 class="modal-title">Edit Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_u" name="id" class="form-control" required>
						<div class="form-group">
							<label>Taxpayer Identification Number (TIN)</label>
							<input type="text" id="tin_u" name="tin" class="form-control" required>
						</div>
						<div class="form-group">
							<label>RDO</label>
							<input type="text" id="rdo_u" name="rdo" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name of Taxpayer/Contractor</label>
							<input type="text" id="name_u" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>ZIP Code</label>
							<input type="text" id="zip_u" name="zip" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Contact Number (+63)</label>
							<input type="tel" id="phone_u" name="phone" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Taxpayer Classification:</label>
				<select name="taxpayer" id="taxpayer_u"class="form-control"required>
            <option value="Individual">Individual</option>
            <option value="Corporation">Corporation</option>
        </select>
						</div>
						<div class="form-group">
							<label>PSIC</label>
							<input type="text" id="pcic_u" name="pcic" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project Name</label>
							<input type="text" id="pname_u" name="pname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project Location</label>
							<input type="text" id="plocation_u" name="plocation" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Project ID Number</label>
							<input type="text" id="pnumber_u" name="pnumber" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded</label>
							<input type="date" id="dawarded_u" name="dawarded" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed</label>
							<input type="date" id="dcompleted_u" name="dcompleted" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded Contract Price</label>
							<input type="date" id="dacp_u" name="dacp" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Date Completed Contract Price</label>
							<input type="date" id="dccp_u" name="dccp" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Awarded Progress Billings Collected</label>
							<input type="date" id="dapbc_u" name="dapbc" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed_Progress Billings Collected</label>
							<input type="date" id="dcpbc_u" name="dcpbc" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded VAT</label>
							<input type="date" id="davat_u" name="davat" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed VAT</label>
							<input type="date" id="dcvat_u" name="dcvat" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded Creditable Withholding Tax</label>
							<input type="date" id="dacwt_u" name="dacwt" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Completed Creditable Withholding Tax</label>
							<input type="date" id="dccwt_u" name="dccwt" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Awarded Total Amount Collected</label>
							<input type="date" id="datapt_u" name="datapt" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Completed Total Amount Collected</label>
							<input type="date" id="dctapt_u" name="dctapt" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Awarded Collectible Final Payment</label>
							<input type="date" id="dacfp_u" name="dacfp" class="form-control">
						</div>
						<div class="form-group">
							<label>Date Completed Collectible Final Payment</label>
							<input type="date" id="dccfp_u" name="dccfp" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>

					</div>
					<div class="modal-footer">
					<input type="hidden" value="2" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-info" id="update">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>

					<div class="modal-header">
						<h4 class="modal-title">Delete Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_d" name="id" class="form-control">
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-danger" id="delete">Delete</button>
					</div>
				</form>
			</div>
		</div>
	</div>

</body>
</html>
