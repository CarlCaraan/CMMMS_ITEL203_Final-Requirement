<?php
include 'backend/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manage - Application For Scholarship Of Laguna</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/crud_user.css?v=<?php echo time(); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="ajax/ajax1.js"></script>
</head>

<body>

		<!--table-->
    <div class="container">
	<p id="success"></p>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Records</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="logout.php" type="button" class="btn btn-danger" id="logout_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe9ba;</i>Logout</a>
						<a href="g_form1.php" type="button" class="btn btn-danger" id="back_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe85d;</i>back</a>
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xe7fe;</i> <span>Add Records</span></a>
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons">&#xef66;</i> <span>Delete</span></a>
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th>
						<th>ID</th>
                        <th>Name</th>
                        <th>Slot No.</th>
												<th>Age</th>
                        <th>Sex</th>
												<th>Status</th>
                        <th>Religion</th>
                        <th>Date Of Birth</th>
												<th>Place Of Birth</th>
												<th>Residential Address In Laguna</th>
                        <th>Province</th>
												<th>Municipality</th>
                        <th>Barangay</th>
                        <th>Telephone no./ Cel no. (+63)</th>
												<th>Email Address</th>
                        <th>Name Of Father</th>
												<th>Occupation</th>
                        <th>Income Per Month</th>
                        <th>Name Of Mother</th>
												<th>Occupation</th>
                        <th>Income Per Month</th>
												<th>Name Of Guardian</th>
												<th>Relation</th>
                        <th>Income Per Month</th>
                        <th>Telephone no./ Cel no. (+63)</th>
												<th>Annual Family Gross Income</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
				<tbody>

				<?php
				$result = mysqli_query($conn,"SELECT * FROM iskolaguna");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					<td><?php echo $i; ?></td>
					<td><?php echo $row["name"]; ?></td>
					<td><?php echo $row["slot"]; ?></td>
					<td><?php echo $row["age"]; ?></td>
					<td><?php echo $row["sex"]; ?></td>
					<td><?php echo $row["status"]; ?></td>
					<td><?php echo $row["religion"]; ?></td>
					<td><?php echo $row["dob"]; ?></td>
					<td><?php echo $row["pob"]; ?></td>
					<td><?php echo $row["resadd"]; ?></td>
					<td><?php echo $row["prov"]; ?></td>
					<td><?php echo $row["mun"]; ?></td>
					<td><?php echo $row["brgy"]; ?></td>
					<td><?php echo $row["cel"]; ?></td>
					<td><?php echo $row["email"]; ?></td>
					<td><?php echo $row["fat"]; ?></td>
					<td><?php echo $row["oc1"]; ?></td>
					<td><?php echo $row["inc1"]; ?></td>
					<td><?php echo $row["mot"]; ?></td>
					<td><?php echo $row["oc2"]; ?></td>
					<td><?php echo $row["inc2"]; ?></td>
					<td><?php echo $row["gua"]; ?></td>
					<td><?php echo $row["rel"]; ?></td>
					<td><?php echo $row["inc3"]; ?></td>
					<td><?php echo $row["cel1"]; ?></td>
					<td><?php echo $row["afgi"]; ?></td>
					<td>
						<a href="#editEmployeeModal" class="edit" data-toggle="modal">
							<i class="material-icons update" data-toggle="tooltip"
							data-id="<?php echo $row["id"]; ?>"
							data-name="<?php echo $row["name"]; ?>"
							data-slot="<?php echo $row["slot"]; ?>"
							data-age="<?php echo $row["age"]; ?>"
							data-sex="<?php echo $row["sex"]; ?>"
							data-status="<?php echo $row["status"]; ?>"
							data-religion="<?php echo $row["religion"]; ?>"
							data-dob="<?php echo $row["dob"]; ?>"
							data-pob="<?php echo $row["pob"]; ?>"
							data-resadd="<?php echo $row["resadd"]; ?>"
							data-prov="<?php echo $row["prov"]; ?>"
							data-mun="<?php echo $row["mun"]; ?>"
							data-brgy="<?php echo $row["brgy"]; ?>"
							data-cel="<?php echo $row["cel"]; ?>"
							data-email="<?php echo $row["email"]; ?>"
							data-fat="<?php echo $row["fat"]; ?>"
							data-oc1="<?php echo $row["oc1"]; ?>"
							data-inc1="<?php echo $row["inc1"]; ?>"
							data-mot="<?php echo $row["mot"]; ?>"
							data-oc2="<?php echo $row["oc2"]; ?>"
							data-inc2="<?php echo $row["inc2"]; ?>"
							data-gua="<?php echo $row["gua"]; ?>"
							data-rel="<?php echo $row["rel"]; ?>"
							data-inc3="<?php echo $row["inc3"]; ?>"
							data-cel1="<?php echo $row["cel1"]; ?>"
							data-afgi="<?php echo $row["afgi"]; ?>"
							title="Edit">&#xE254;</i>
						</a>
						<a href="#deleteEmployeeModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
						 title="Delete">&#xE872;</i></a>
                    </td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>

        </div>
    </div>
	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form">
					<div class="modal-header">
						<h4 class="modal-title">Add Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>Name</label>
							<input type="text" id="name" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Slot</label>
							<input type="text" id="slot" name="slot" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Age</label>
							<input type="text" id="age" name="age" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Sex</label>
				<select name="sex" id="sex"class="form-control"required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
						</div>
						<div class="form-group">
							<label>Status</label>
				<select name="status" id="status" class="form-control" required>
            <option value="Single">Single</option>
            <option value="Married">Married</option>
            <option value="Widowed">Widowed</option>
            <option value="Divorced">Divorced</option>
            <option value="Separated">Separated</option>
        </select>
						</div>
						<div class="form-group">
							<label>Religion</label>
							<input type="text" id="religion" name="religion" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Of Birth</label>
							<input type="date" id="dob" name="dob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Place Of Birth</label>
							<input type="text" id="pob" name="pob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Residential Address In Laguna</label>
							<input type="text" id="resadd" name="resadd" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="prov" name="prov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Municipality</label>
							<input type="text" id="mun" name="mun" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Barangay</label>
							<input type="text" id="brgy" name="brgy" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Tel no./ Cel no. (+63)</label>
							<input type="tel" id="cel" name="cel" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Email Address</label>
							<input type="email" id="email" name="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Father</label>
							<input type="text" id="fat" name="fat" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Occupation</label>
							<input type="text" id="oc1" name="oc1" class="form-control">
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc1" name="inc1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Mother</label>
							<input type="text" id="mot" name="mot" class="form-control">
						</div>
						<div class="form-group">
							<label>Occupation</label>
							<input type="text" id="oc2" name="oc2" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc2" name="inc2" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Guardian</label>
							<input type="text" id="gua" name="gua" class="form-control">
						</div>
						<div class="form-group">
							<label>Relation</label>
							<input type="text" id="rel" name="rel" class="form-control">
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc3" name="inc3" class="form-control">
						</div>
						<div class="form-group">
							<label>Tel no./ Cel no. (+63)</label>
							<input type="tel" id="cel1" name="cel1" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Annual Family Gross Income</label>
							<input type="number" id="afgi" name="afgi" class="form-control" required>
						</div>
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="update_form">
					<div class="modal-header">
						<h4 class="modal-title">Edit Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_u" name="id" class="form-control" required>
						<div class="form-group">
							<label>Name</label>
							<input type="text" id="name_u" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Slot</label>
							<input type="text" id="slot_u" name="slot" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Age</label>
							<input type="text" id="age_u" name="age" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Sex</label>
				<select name="sex" id="sex_u"class="form-control"required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
						</div>
						<div class="form-group">
							<label>Status</label>
				<select name="status" id="status_u" class="form-control" required>
            <option value="Single">Single</option>
            <option value="Married">Married</option>
            <option value="Widowed">Widowed</option>
            <option value="Divorced">Divorced</option>
            <option value="Separated">Separated</option>
        </select>
						</div>
						<div class="form-group">
							<label>Religion</label>
							<input type="text" id="religion_u" name="religion" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date Of Birth</label>
							<input type="date" id="dob_u" name="dob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Place Of Birth</label>
							<input type="text" id="pob_u" name="pob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Residential Address In Laguna</label>
							<input type="text" id="resadd_u" name="resadd" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="prov_u" name="prov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Municipality</label>
							<input type="text" id="mun_u" name="mun" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Barangay</label>
							<input type="text" id="brgy_u" name="brgy" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Tel no./ Cel no. (+63)</label>
							<input type="tel" id="cel_u" name="cel" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Email Address</label>
							<input type="email" id="email_u" name="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Father</label>
							<input type="text" id="fat_u" name="fat" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Occupation</label>
							<input type="text" id="oc1_u" name="oc1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc1_u" name="inc1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Mother</label>
							<input type="text" id="mot_u" name="mot" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Occupation</label>
							<input type="text" id="oc2_u" name="oc2" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc2_u" name="inc2" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Name Of Guardian</label>
							<input type="text" id="gua_u" name="gua" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Relation</label>
							<input type="text" id="rel_u" name="rel" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Income Per Month</label>
							<input type="number" id="inc3_u" name="inc3" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Tel no./ Cel no. (+63)</label>
							<input type="tel" id="cel1_u" name="cel1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Annual Family Gross Income</label>
							<input type="number" id="afgi_u" name="afgi" class="form-control" required>
						</div>
					</div>
					<div class="modal-footer">
					<input type="hidden" value="2" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-info" id="update">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>

					<div class="modal-header">
						<h4 class="modal-title">Delete Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_d" name="id" class="form-control">
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-danger" id="delete">Delete</button>
					</div>
				</form>
			</div>
		</div>
	</div>

</body>
</html>
