<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home - CMMMS</title>
<link rel="stylesheet" href="css/home.css?v=<?php echo time(); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<style>
h2 {
  background-color: #ff4654;
  text-align: left;
  font-size: 32px;
  color: white;
  padding-left: 20px;
  padding-top: 15px;
  padding-bottom: 15px;
  font-family: Segoe UI Black;
  border-radius:5px;
  margin:0px 10px 0px 10px;
}

h3 {
  color: #ff4654;
  font-family: Segoe UI;
  padding-left: 20px;
}

p {
  color: #0f1821;
  padding-left: 20px;
  font-family: Segoe UI Light;
}

th {
  color: #0f1821;
  font-family: Segoe UI;
}

th {
  font-family: Segoe UI;
  color: #0f1821;
}
/*Navbar*/
/*embedded*/
/* Style The Dropdown Button */
.dropbtn {
  background-color: transparent;
  color: white;
  font-size: 19px;
  border: none;
  cursor: pointer;
  padding:29px 24px 9px;
}
.dropbtn:hover{
  color:#FD4556;
  transition: all 0.3s ease;
}
.dropbtn2 {
  background-color: transparent;
  color: white;
  font-size: 16px;
  border: none;
  cursor: pointer;
  margin-left:10px;
}
.dropbtn2:hover{
  color:#FD4556;
  transition: all 0.3s ease;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}


/***FOR DROPDOWN 1 (Government Forms)***/
/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #282828;
  min-width: 300px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {
  background-color: #323131;
  color: #FD4556;
}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}


/***FOR DROPDOWN 2 (User)***/
/* Dropdown Content (Hidden by Default) */
.dropdown-content2 {
  display: none;
  position: absolute;
  background-color: #282828;
  min-width: 150px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
/* Links inside the dropdown */
.dropdown-content2 a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content2 a:hover {
  background-color: #323131;
  color: #FD4556;
}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content2 {
  display: block;
}


/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
  background-color: #0c131b;
}
</style>
<body>
<!--navbar-->
	<nav class="navbar">
		<div class="navbar__container">
		<a href="#home" id="navbar__logo"><img src="img/logo.png" style="width:175px; height:200px;"></a>
		<ul class="navbar__menu">
		<li class="navbar__item">
			<a href="home.php" class="navbar__links" id="home-page"></i>Home
      </a>
		</li>
		<li class="navbar__item">
			<!--Dropdown Government Forms-->
  <div class="dropdown">
    <button class="dropbtn"><b>Forms</b></button>
    <div class="dropdown-content">
    <a href="g_form1.php">Application for Scholarship of Laguna</a>
    <a href="g_form2.php">Application for Contractor’s Final Payment Release Certificate</a>
    <a href="g_form3.php">Application for Postal Id Card</a>
    <a href="g_form4.php">Application for Birth Certificate</a>
    <a href="g_form5.php">Application for Ched Scholarship Program (CSP)</a>
    </div>
  </div>

		</li>
		<li class="navbar__item">
			<a href="about.php" class="navbar__links" id="about-us">About Us</a>
		</li>
		<li class="navbar__item">
			<a href="contact.php" class="navbar__links" id="contact-us">Contact Us</a>
		</li>
		<li class="navbar__btn">

  <?php

  session_start();

  if (!isset($_SESSION['username'])) {
      header("Location: login.php");
  }

  ?>

			<!--Dropdown for User-->
  <div class="dropdown">
  <?php echo "<button class='dropbtn2'><b style='font-size: 16px'; text-align:center>Welcome <br>". $_SESSION['username'] ."</b></button>"?>
    <div class="dropdown-content2">
    <a href="crud_user.php">Manage User</a>
    <a href="logout.php">Logout</a>
    </div>
  </div>
		</li>
		</ul>
		</div>
	</nav>

<!--content-->
<br>
<h3>Final Requirement for ITEL-203</h3>

<p>• This HTML Webpage serves as a final project and uses for educational purposes only.</p>
<br>

<header>
  <h2>GOVERNMENT FORMS</h2>
</header>
<footer>

<section>
  <table style="padding: 12px; border: 1px; width: 100%" cellpadding="0" cellspacing="0">

  <tr>
    <th><div class="popup"><img style="height:300px; width:218px; padding: 5px; margin: 10px" src ="form1.jpg"></div>
<!--pop up image-->
      <div class="show">
        <div class="overlay"></div>
        <div class="img-show">
          <span>X</span>
          <img src="img/carl.jpg">
        </div>
      </div>

    </th>
    <th><div class="popup"><img style="height:300px; width:218px; padding: 5px; margin: 10px" src ="form2.jpg"></div>
    </th>
    <th><div class="popup"><img style="height:300px; width:218px; padding: 5px; margin: 10px" src ="form3.jpg"></div>
    </th>
    <th><div class="popup"><img style="height:300px; width:218px; padding: 5px; margin: 10px" src ="form4.jpg"></div>
    </th>
    <th><div class="popup"><img style="height:300px; width:218px; padding: 5px; margin: 10px" src ="form5.jpg"></div>
    </th>
  </tr>

  <tr>
    <th style="margin: 30px; padding: 12px">Application for<br>Scholarship of Laguna</th>
    <th style="margin: 30px; padding: 12px">Application for Contractor’s<br>Final Payment Release Certificate</th>
    <th style="margin: 30px; padding: 12px">Application for<br>Postal Id Card</th>
    <th style="margin: 30px; padding: 12px">Application for<br>Birth Certificate</th>
    <th style="margin: 30px; padding: 12px">Application for Ched<br>Scholarship Program (CSP)</th>
  </tr>

</table>

  <br>
<br>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>

<script>
$(function () {
    "use strict";

    $(".popup img").click(function () {
        var $src = $(this).attr("src");
        $(".show").fadeIn();
        $(".img-show img").attr("src", $src);
    });

    $("span, .overlay").click(function () {
        $(".show").fadeOut();
    });

});
</script>

</body>
</html>
