<!-- Add user -->
	$(document).on('click','#btn-add',function(e) {
		var data = $("#user_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form1.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#addEmployeeModal').modal('hide');
						alert('Data added successfully !');
                        location.reload();
					} else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on('click','.update',function(e) {
		var id=$(this).attr("data-id");
		var name=$(this).attr("data-name");
		var slot=$(this).attr("data-slot");
		var age=$(this).attr("data-age");
		var sex=$(this).attr("data-sex");
		var status=$(this).attr("data-status");
		var religion=$(this).attr("data-religion");
		var dob=$(this).attr("data-dob");
		var pob=$(this).attr("data-pob");
		var resadd=$(this).attr("data-resadd");
		var prov=$(this).attr("data-prov");
		var mun=$(this).attr("data-mun");
		var brgy=$(this).attr("data-brgy");
		var cel=$(this).attr("data-cel");
		var email=$(this).attr("data-email");
		var fat=$(this).attr("data-fat");
		var oc1=$(this).attr("data-oc1");
		var inc1=$(this).attr("data-inc1");
		var mot=$(this).attr("data-mot");
		var oc2=$(this).attr("data-oc2");
		var inc2=$(this).attr("data-inc2");
		var gua=$(this).attr("data-gua");
		var rel=$(this).attr("data-rel");
		var inc3=$(this).attr("data-inc3");
		var cel1=$(this).attr("data-cel1");
		var afgi=$(this).attr("data-afgi");
		$('#id_u').val(id);
		$('#name_u').val(name);
		$('#slot_u').val(slot);
		$('#age_u').val(age);
		$('#sex_u').val(sex);
		$('#status_u').val(status);
		$('#religion_u').val(religion);
		$('#dob_u').val(dob);
		$('#pob_u').val(pob);
		$('#resadd_u').val(resadd);
		$('#prov_u').val(prov);
		$('#mun_u').val(mun);
		$('#brgy_u').val(brgy);
		$('#cel_u').val(cel);
		$('#email_u').val(email);
		$('#fat_u').val(fat);
		$('#oc1_u').val(oc1);
		$('#inc1_u').val(inc1);
		$('#mot_u').val(mot);
		$('#oc2_u').val(oc2);
		$('#inc2_u').val(inc2);
		$('#gua_u').val(gua);
		$('#rel_u').val(rel);
		$('#inc3_u').val(inc3);
		$('#cel1_u').val(cel1);
		$('#afgi_u').val(afgi);
	});
<!-- Update -->
	$(document).on('click','#update',function(e) {
		var data = $("#update_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form1.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#editEmployeeModal').modal('hide');
						alert('Data updated successfully !');
                        location.reload();
					}
					else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on("click", ".delete", function() {
		var id=$(this).attr("data-id");
		$('#id_d').val(id);

	});
	$(document).on("click", "#delete", function() {
		$.ajax({
			url: "backend/crud_g_form1.php",
			type: "POST",
			cache: false,
			data:{
				type:3,
				id: $("#id_d").val()
			},
			success: function(dataResult){
					$('#deleteEmployeeModal').modal('hide');
					$("#"+dataResult).remove();

			}
		});
	});
	$(document).on("click", "#delete_multiple", function() {
		var user = [];
		$(".user_checkbox:checked").each(function() {
			user.push($(this).data('user-id'));
		});
		if(user.length <=0) {
			alert("Please select records.");
		}
		else {
			WRN_PROFILE_DELETE = "Are you sure you want to delete "+(user.length>1?"these":"this")+" row?";
			var checked = confirm(WRN_PROFILE_DELETE);
			if(checked == true) {
				var selected_values = user.join(",");
				console.log(selected_values);
				$.ajax({
					type: "POST",
					url: "backend/crud_g_form1.php",
					cache:false,
					data:{
						type: 4,
						id : selected_values
					},
					success: function(response) {
						var ids = response.split(",");
						for (var i=0; i < ids.length; i++ ) {
							$("#"+ids[i]).remove();
						}
					}
				});
			}
		}
	});
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		var checkbox = $('table tbody input[type="checkbox"]');
		$("#selectAll").click(function(){
			if(this.checked){
				checkbox.each(function(){
					this.checked = true;
				});
			} else{
				checkbox.each(function(){
					this.checked = false;
				});
			}
		});
		checkbox.click(function(){
			if(!this.checked){
				$("#selectAll").prop("checked", false);
			}
		});
	});
