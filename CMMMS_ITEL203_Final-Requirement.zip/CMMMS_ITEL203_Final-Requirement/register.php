<?php

include 'config.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: index.php");
}

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);
	#$password = ($_POST['password']);
	#$cpassword = ($_POST['cpassword']);

	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users (username, email, password)
					VALUES ('$username', '$email', '$password')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('Wow! User Registration Completed.')</script>";
				$username = "";
				$email = "";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('Woops! Email Already Exists.')</script>";
		}

	} else {
		echo "<script>alert('Password Not Matched.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="css\login.css?v=<?php echo time(); ?>">

	<title>Register - CMMMS</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800; color: #0f1821;">Register</p>
			<div class="input-group">
				<input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
			</div>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
            </div>
            <div class="input-group">
				<input type="password" placeholder="Confirm Password" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
			</div>

      <center><input type="checkbox" name"toa" id"toa" class="toa" value"" onclick="openForm()"required>  By creating an account you agree to<a href="#" onclick="openForm()"><br> Terms and Privacy</a></center><br>

			<div class="input-group">
				<button name="submit" class="btn">Register</button>
			</div>
			<p class="login-register-text">Have an account? <a href="index.php">Login Here</a>.</p>
		</form>
	</div>

<!--pop-up-->
    <div class="form-popup" id="myForm">
  <form  class="form-container">
    <center><h2>Terms Conditions and Policy Agreement</h2></center>
    <br><br>
    <p style="font-size:15px"><b>
      Terms of Use:</center>
    </b></p>
      &nbsp DISCLAIMER: Any type of form is for personal use only.<br>
      &nbsp We will not make or sell any of these copy to anyone else.
    <p style="font-size:15px"><b><br>
      Personal Data Protection Policy:
    </b></p>
    &nbsp We ensure that all your data is safe and used for <br>&nbsp school purposes.<br><br><br><hr>
    <p style="font-size: 4px">
    <center><p style="font-size: 14px">Terms Conditions and Policy Agreement</p></center>
    <input type="checkbox" class="selectall" id="chb1" onclick="myFunction()"required><label style="font-size:12px">I have read and accepted the Terms of Use.</label><br>
    <input type="checkbox" class="selectall" id="chb2" onclick="myFunction()"required><label style="font-size:12px">I have read and accepted the Personal Data Protection Notice. I give my consent to CMMMS(Dev Team).
    and government forms entities to collect use disclose, share and/or process my Personal Data as stated in the Personal Data Protection Policy.</label><br>
    <input type="checkbox" class="selectall" id="chb3" onclick="myFunction()"required><label style="font-size:12px">I understand that my Personal Data may be used for school purposes only. note you will not receive any marketing
    and other communications by:</label><br><br><br>
<div class="pnc__container">
  <div class="pnc_wrapper1">
    <button type="button" class="btn proceed" id="hide_prc" onclick="closeForm()">Agree</button>
    <button type="submit" class="btn submit" id="show_prc">Agree</button>
  </div>
  <div class="pnc__wrapper2">
  </div>
  <div class="pnc_wrapper3">
    <button type="button" class="btn cancel" id="cnl"><a href="register.php">Cancel</a></button>
  </div>
</div>
  </form>
</div>

<!--javascript-->

  <script>
//popup box show and hide
  function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

//agree buton show and hide
function myFunction() {
  var checkBox1 = document.getElementById("chb1");
  var checkBox2 = document.getElementById("chb2");
  var checkBox3 = document.getElementById("chb3");
  var prc = document.getElementById("hide_prc");
  if (checkBox1.checked == true && checkBox2.checked == true && checkBox3.checked == true){
    hide_prc.style.display = "block";
    show_prc.style.display = "none";
  } else {
     hide_prc.style.display = "none";
     show_prc.style.display = "block";
  }
}

//button=checked the checkbox
$(".selectall").click(function(){
$(".toa").prop("checked",$(this).prop("checked"));
});
</script>

</body>
</html>
