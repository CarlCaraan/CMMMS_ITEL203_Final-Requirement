<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$pid=$_POST['pid'];
		$rev=$_POST['rev'];
		$acn=$_POST['acn'];
		$poc=$_POST['poc'];
		$pon=$_POST['pon'];
		$orno=$_POST['orno'];
		$ordate=$_POST['ordate'];
		$prn=$_POST['prn'];
		$purpose=$_POST['purpose'];
		$optional=$_POST['optional'];
		$fname=$_POST['fname'];
		$mname=$_POST['mname'];
		$lname=$_POST['lname'];
		$suffix=$_POST['suffix'];
		$gender=$_POST['gender'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$prov=$_POST['prov'];
		$country=$_POST['country'];

	$sql = "INSERT INTO `postal`(`pid`,`rev`,`acn`,`poc`,`pon`,`orno`,`ordate`,`prn`,`purpose`,`optional`,`fname`,`mname`,`lname`,
		`suffix`,`gender`,`dob`,`pob`,`prov`,`country`)
	 VALUES('$pid','$rev','$acn','$poc','$pon','$orno','$ordate','$prn','$purpose',
		 '$optional','$fname','$mname','$lname','$suffix','$gender','$dob','$pob','$prov','$country')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$pid=$_POST['pid'];
		$rev=$_POST['rev'];
		$acn=$_POST['acn'];
		$poc=$_POST['poc'];
		$pon=$_POST['pon'];
		$orno=$_POST['orno'];
		$ordate=$_POST['ordate'];
		$prn=$_POST['prn'];
		$purpose=$_POST['purpose'];
		$optional=$_POST['optional'];
		$fname=$_POST['fname'];
		$mname=$_POST['mname'];
		$lname=$_POST['lname'];
		$suffix=$_POST['suffix'];
		$gender=$_POST['gender'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$prov=$_POST['prov'];
		$country=$_POST['country'];

		$sql = "UPDATE `postal` SET `pid`='$pid',`rev`='$rev',`acn`='$acn',`poc`='$poc',`pon`='$pon',`orno`='$orno',
		`ordate`='$ordate',`prn`='$prn',`purpose`='$purpose',`optional`='$optional',
		`fname`='$fname',`mname`='$mname',`lname`='$lname',`suffix`='$suffix',`gender`='$gender',`dob`='$dob',`pob`='$pob',`prov`='$prov',`country`='$country' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `postal` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM postal WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
