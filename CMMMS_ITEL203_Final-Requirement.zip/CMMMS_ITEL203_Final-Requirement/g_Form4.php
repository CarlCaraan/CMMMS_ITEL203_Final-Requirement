<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Application for Birth Certificate</title>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="css/g_form4.css?v=<?php echo time(); ?>">
</head>

<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=date], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=tel], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>

<body>

<!--header navbar-->
<?php
include_once 'header2.php';
?>
<!--continuation-->
                    <a href='g_form3.php' class="button" id="login-page"><i class="material-icons">&#xe5cb;</i>previous</a>
                </li>
                <li class="navbar__btn">
                    <a href='g_form5.php' class="button" id="login-page"><i class="material-icons">&#xe409;</i>next</a>
                </li>
                <li class="navbar__btn">
                    <a href='crud_g_form4.php' class="button" id="login-page"><i class="fas fa-database" style="margin-right:2px"></i>manage</a>
                </li>
            </ul>
        </div>
    </nav>
<?php
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$req=$_POST['req'];
	$copies=$_POST['copies'];
	$others=$_POST['others'];
	$brn=$_POST['brn'];
	$gender=$_POST['gender'];
	$lname=$_POST['lname'];
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$dob=$_POST['dob'];
	$pob=$_POST['pob'];
	$prov=$_POST['prov'];
	$country=$_POST['country'];
	$lnamef=$_POST['lnamef'];
	$fnamef=$_POST['fnamef'];
	$mnamef=$_POST['mnamef'];
	$lnamem=$_POST['lnamem'];
	$fnamem=$_POST['fnamem'];
	$mnamem=$_POST['mnamem'];
	$late=$_POST['late'];
	$when1=$_POST['when1'];
	$tin=$_POST['tin'];
	$tn=$_POST['tn'];
	$extra=$_POST['extra'];
	$specou=$_POST['specou'];
	$rfull=$_POST['rfull'];
	$madd=$_POST['madd'];
	$mcity=$_POST['mcity'];
	$mprov=$_POST['mprov'];
	$mpho=$_POST['mpho'];
	$sql = "INSERT INTO birthcert(req,copies,others,brn,gender,lname,fname,mname,dob,pob,prov,country,lnamef,fnamef,mnamef,lnamem,fnamem,mnamem,late,when1,tin,tn,extra,specou,rfull,madd,mcity,mprov,mpho)VALUES('$req','$copies','$others','$brn','$gender','$lname','$fname','$mname','$dob','$pob','$prov','$country','$lnamef','$fnamef','$mnamef','$lnamem','$fnamem','$mnamem','$late','$when1','$tin','$tn','$extra','$specou','$rfull','$madd','$mcity','$mprov','$mpho')";
		$result = mysqli_query($conn, $sql);
	echo "<script>alert('Wow! User Registration Completed.')</script>";
}
 ?>

<div class="form__container">
  <!--this form is not for sale-->
  <div class="notsale__container">
<p style="FONT-Family:sans-serif; text-align:center; color: white"><b>THIS FORM IS NOT FOR SALE</b></p>
  </div>
<!--header title-->
  <div class="header--title__wrapper">
    <div class="title--text__card">
      REPUBLIC OF THE PHILIPPINES <br>
      PHILIPPINE STATISTICS AUTHORITY <br>
        <b>OFFICE OF THE CIVIL REGISTRAR GENERAL</b> <br>
        <b>APPLICATION FORM BIRTH CERTIFICATE</b><br>
    </div>
    <!--logo-->
    <div class="title--logo__card">
  <img src="img\logo4.png" alt="logo" width="80" height="80" style="justify-content:center;">
    </div>
  </div>
  <div class="important__container">
    <p style="background-color: #424242; padding: 1px; color: white;text-align:center">IMPORTANT: PLEASE READ GENERAL INSTRUCTIONS BEFORE FILLING OUT THE FORM</p>
    <p style="justify-content: center; text-align:center;">
      1. Please PRINT letters in the spaces provided. Please CHECK appropriate Boxes. <br>
      2. A valid ID is required for both owner & requester of document. <br>
      3. An authorization is required from representative upon filing of the application.
    </p>
    <hr>
    <hr>
  </div>
  <div class="allforms__container">
    <form method="post">
			<caption>Request for:</caption>
				<input type="radio" name="req" value="Birth Certificate"><b>Birth Certificate</b>
				<input type="radio" name="req" value="Authentication"><b>Authentication</b>
				<input type="radio" name="req" value="Birth Card"><b>Birth Card</b>
				<input type="radio" name="req" value="CDLI"><b>CDLI</b>
        <hr>
			<caption>Number of Copies:</caption>
		<input type="radio" id="One" name="copies" value="1">
		<label for="One">One</label>
		<input type="radio" id="Two" name="copies" value="2">
		<label for="Two">Two</label>
        &nbsp &nbsp &nbsp &nbsp &nbsp
				Others(specify):<input type="text" name="others" size="6"placeholder="   Specify"><br/><br/>
        <hr>
			<caption>Birth Reference No. <br> BReN(if Known):</caption>
				Others(specify):<input type="text" name="brn" size="30"placeholder="   Specify">
        &nbsp &nbsp &nbsp &nbsp &nbsp
			<caption>Sex:</caption>
<input type="radio" id="Male" name="gender" value="Male">
  <label for="Male">Male</label>
  <input type="radio" id="Female" name="gender" value="Female">
  <label for="Female">Female</label>
        <hr>
			<caption><b style="font-family: sans-serif">OWNER'S PERSONAL INFORMATION</b>(For married female, please use maiden name):</caption> <br><br>
				Last Name:&nbsp&nbsp&nbsp<input type="text" name="lname" size="50"placeholder="   Last Name"required><br/><br/>
				First Name:&nbsp&nbsp&nbsp<input type="text" name="fname" size="50"placeholder="   First Name"required><br/><br/>
				Middle Name:<input type="text" name="mname" size="50"placeholder="   Middle Name"required><br/><br/>
				Date of Birth:<input type="date" name="dob" placholder ="" size ="50"required><br>
        <br>
				Place of Birth:<input type="text" name="pob" size="50"placeholder="   City/Municipality"required><br/><br/>
         <br>
        &nbsp &nbsp &nbsp &nbsp &nbsp
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
				<input type="text" name="prov" size="50"placeholder="   Province"required><br>
         <br>
        <hr>
        Please specify country if born abroad only:
				<input type="text" name="country" size="24"placeholder="   Country"required><br>
        Country <br>
        <hr>
			<caption><b>Name of Father:</b></caption><br>
				Last Name:&nbsp&nbsp&nbsp<input type="text" name="lnamef" size="50"placeholder="   Last Name"required><br/><br/>
				First Name:&nbsp&nbsp&nbsp<input type="text" name="fnamef" size="50"placeholder="   First Name"required><br/><br/>
				Middle Name:<input type="text" name="mnamef" size="50"placeholder="   Middle Name"required><br/><br/>
      <hr>
			<caption><b>Name of Mother:</b></caption><br>
				Last Name:&nbsp&nbsp&nbsp<input type="text" name="lnamem" size="50"placeholder="   Last Name"required><br/><br/>
				First Name:&nbsp&nbsp&nbsp<input type="text" name="fnamem" size="50"placeholder="   First Name"required><br/><br/>
				Middle Name:<input type="text" name="mnamem" size="50"placeholder="   Middle Name"required><br/><br/>
        <hr>
			<caption><b>Registered Late?:<br></b>
        Choose appropriate box 	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        </caption>
		<input type="radio" name="late" value="No">No
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="radio" name="late" value="Yes">Yes
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				When:<input type="date" name="when1" placholder ="" size ="10"><br/><br/>
        <hr>
Requester's Tax Identification No.(TIN)(If Known):
<input type="text" name="tin" size="15"placeholder="   Please Specify"><br>
<hr>
for PSA use only <br>
<B style="font-family: sans-serif">TRANSACTION NUMBER:</B>
				<input type="text" name="tn" size="35"placeholder=""><br>
        <hr>
        <b>PURPOSE:</b> Choose one and choose appropriate box <br> <br>
				<input type="radio" name="extra" value="Claim Benefits/Loan">Claim Benefits/Loan
				<input type="radio" name="extra" value="Passport/Travel">Passport/Travel
				<input type="radio" name="extra" value="Employment Abroad">Employment Abroad
				<input type="radio" name="extra" value="Employment Local">Employment Local
				<input type="radio" name="extra" value="School Requirements">School Requirements
				<input type="radio" name="extra" value="Others">Others <br>

				(Specify Country):<input type="text" name="specou" size=""placeholder="   Country"><br/><br/>
        <hr>
        <b>REQUESTER'S INFORMATION</b>
			<input type="text" name="rfull" size="30"placeholder="   Last Name, First Name, MI"required><br>
       &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
      &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
       &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp

        <br> <br>

       Mailing Address:
       &nbsp &nbsp
			<input type="text" name="madd" size="30"placeholder="   Brgy/Street"required><br>
       City/ Municipality:
       &nbsp
			<input type="text" name="mcity" size="30"placeholder="   City/Municipality"required><br>
       Province:
       &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp
			<input type="text" name="mprov" size="30"placeholder="   Province"required><br>
       Tel No.
       &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp
			<input type="tel"  name="mpho" size="30" placeholder="   912-345-6789"pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required><hr>
      <div class="savereset__container">
				<input type="submit" name="submit" value="SUBMIT">
				<input type="Reset" name="clear" Value="RESET">
			</div>
    </form>

  </div>

</div>
<br><br>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>

</body>
</html>
