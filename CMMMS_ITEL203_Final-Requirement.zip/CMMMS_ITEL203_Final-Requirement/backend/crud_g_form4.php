<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$req=$_POST['req'];
		$copies=$_POST['copies'];
		$others=$_POST['others'];
		$brn=$_POST['brn'];
		$gender=$_POST['gender'];
		$lname=$_POST['lname'];
		$fname=$_POST['fname'];
		$mname=$_POST['mname'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$prov=$_POST['prov'];
		$country=$_POST['country'];
		$lnamef=$_POST['lnamef'];
		$fnamef=$_POST['fnamef'];
		$mnamef=$_POST['mnamef'];
		$lnamem=$_POST['lnamem'];
		$fnamem=$_POST['fnamem'];
		$mnamem=$_POST['mnamem'];
		$late=$_POST['late'];
		$when1=$_POST['when1'];
		$tin=$_POST['tin'];
		$tn=$_POST['tn'];
		$extra=$_POST['extra'];
		$specou=$_POST['specou'];
		$rfull=$_POST['rfull'];
		$madd=$_POST['madd'];
		$mcity=$_POST['mcity'];
		$mprov=$_POST['mprov'];
		$mpho=$_POST['mpho'];

	$sql = "INSERT INTO `birthcert`(`req`,`copies`,`others`,`brn`,`gender`,`lname`,`fname`,`mname`,`dob`,`pob`,`prov`,`country`,`lnamef`,
		`fnamef`,`mnamef`,`lnamem`,`fnamem`,`mnamem`,`late`,`when1`,`tin`,`tn`,`extra`,`specou`,`rfull`,`madd`,`mcity`,`mprov`,`mpho`)
	 VALUES('$req','$copies','$others','$brn','$gender','$lname','$fname','$mname','$dob',
		 '$pob','$prov','$country','$lnamef','$fnamef','$mnamef','$lnamem','$fnamem','$mnamem','$late','$when1','$tin','$tn','$extra',
     '$specou','$rfull','$madd','$mcity','$mprov','$mpho')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$req=$_POST['req'];
		$copies=$_POST['copies'];
		$others=$_POST['others'];
		$brn=$_POST['brn'];
		$gender=$_POST['gender'];
		$lname=$_POST['lname'];
		$fname=$_POST['fname'];
		$mname=$_POST['mname'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$prov=$_POST['prov'];
		$country=$_POST['country'];
		$lnamef=$_POST['lnamef'];
		$fnamef=$_POST['fnamef'];
		$mnamef=$_POST['mnamef'];
		$lnamem=$_POST['lnamem'];
		$fnamem=$_POST['fnamem'];
		$mnamem=$_POST['mnamem'];
		$late=$_POST['late'];
		$when1=$_POST['when1'];
		$tin=$_POST['tin'];
		$tn=$_POST['tn'];
		$extra=$_POST['extra'];
		$specou=$_POST['specou'];
		$rfull=$_POST['rfull'];
		$madd=$_POST['madd'];
		$mcity=$_POST['mcity'];
		$mprov=$_POST['mprov'];
		$mpho=$_POST['mpho'];


		$sql = "UPDATE `birthcert` SET `req`='$req',`copies`='$copies',`others`='$others',`brn`='$brn',`gender`='$gender',`lname`='$lname',
		`fname`='$fname',`mname`='$mname',`dob`='$dob',`pob`='$pob',
		`prov`='$prov',`country`='$country',`lnamef`='$lnamef',`fnamef`='$fnamef',`mnamef`='$mnamef',`lnamem`='$lnamem',`fnamem`='$fnamem',`mnamem`='$mnamem',
    `late`='$late',`when1`='$when1',`tin`='$tin',`tn`='$tn',
		`extra`='$extra',`specou`='$specou',`rfull`='$rfull',`madd`='$madd',`mcity`='$mcity',`mprov`='$mprov',`mpho`='$mpho' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `birthcert` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM birthcert WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
