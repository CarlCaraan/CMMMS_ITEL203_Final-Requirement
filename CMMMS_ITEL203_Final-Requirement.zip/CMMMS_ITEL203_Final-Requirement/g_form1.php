<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Application for Scholarship of Laguna</title>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="css/g_form1.css?v=<?php echo time(); ?>">
</head>

<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=tel], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=number], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=date], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=email], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>

<body>

<!--header navbar-->
<?php
include_once 'header2.php';
?>

<!--continuation-->
                    <a href='g_form5.php' class="button" id="login-page"><i class="material-icons">&#xe5cb;</i>previous</a>
                </li>
                <li class="navbar__btn">
                    <a href='g_form2.php' class="button" id="login-page"><i class="material-icons">&#xe409;</i>next</a>
                </li>
                <li class="navbar__btn">
                    <a href='crud_g_form1.php' class="button" id="login-page"><i class="fas fa-database" style="margin-right:2px"></i>manage</a>
                </li>
            </ul>
        </div>
    </nav>
<br>
<?php
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$name=$_POST['name'];
	$slot=$_POST['slot'];
	$age=$_POST['age'];
	$sex=$_POST['sex'];
	$status=$_POST['status'];
	$religion=$_POST['religion'];
	$dob=$_POST['dob'];
	$pob=$_POST['pob'];
	$resadd=$_POST['resadd'];
	$prov=$_POST['prov'];
	$mun=$_POST['mun'];
	$brgy=$_POST['brgy'];
	$cel=$_POST['cel'];
	$email=$_POST['email'];
	$fat=$_POST['fat'];
	$oc1=$_POST['oc1'];
	$inc1=$_POST['inc1'];
	$mot=$_POST['mot'];
	$oc2=$_POST['oc2'];
	$inc2=$_POST['inc2'];
	$gua=$_POST['gua'];
	$rel=$_POST['rel'];
	$inc3=$_POST['inc3'];
	$cel1=$_POST['cel1'];
	$afgi=$_POST['afgi'];
	$sql = "INSERT INTO iskolaguna (name,slot,age,sex,status,religion,dob,pob,resadd,prov,mun,brgy,cel,email,fat,oc1,inc1,mot,oc2,inc2,gua,rel,inc3,cel1,afgi) VALUES('$name','$slot','$age','$sex','$status','$religion','$dob','$pob','$resadd','$prov','$mun','$brgy','$cel','$email','$fat','$oc1','$inc1','$mot','$oc2','$inc2','$gua','$rel','$inc3','$cel1','$afgi')";
		$result = mysqli_query($conn, $sql);
	echo "<script>alert('Wow! User Registration Completed.')</script>";
}
 ?>
	<div class="form__container">
		<!--Header-->

<div class="header__card--1">
	<img src="img\Logo2.png" alt="logo" width="180" height="150">
	</div>
	<div class="header__card--2">
<p style="font-size: 15px; text-align:center"> <b>REPUBLIC OF THE PHILIPPINES <br>
PROVINCE OF LAGUNA <br>
OFFICE OF THE GOVERNOR <br>
Provincial Capitol Compound, Sta. Cruz, Laguna</b></p><p style="font-size: 12px"></p><br>	</div>
</div>
<div class="formsbackground__container">
	<!--form-->

	<form method="post">
		<br><br>
		 Name of Student (Last Name, First Name, Middle Name): &nbsp &nbsp &nbsp<input type="text" name="name" size="60" placeholder="   (format)"required>
		 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		  Slot No. <input type="text" name="slot" size="30" placeholder="   Slot No."required> <br>

		 Age:<input type="text" name="age" size="10" placeholder="   Age"required>
		&nbsp &nbsp &nbsp Sex <select name="sex" id=""required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
					&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp	&nbsp

		&nbsp &nbsp &nbsp Status <select name="status" id=""required>
            <option value="Single">Single</option>
            <option value="Married">Married</option>
            <option value="Widowed">Widowed</option>
            <option value="Divorced">Divorced</option>
            <option value="Separated">Separated</option>
        </select>
					&nbsp &nbsp &nbsp
		 Religion: <input type="text" name="religion" size="32" placeholder="   Religion"required><br>

		 Date of Birth (mm/dd/yyyy)
		<input type="date" name="dob" placholder ="" size ="30"required><br>
		 Place of Birth
		<input type="text" name="pob" size="30" placeholder="   City/Province"required>
		 Residential Address in Laguna

		<input type="text" name="resadd" size="30" placeholder="   City/Province"required>
		<br>
		 Province
		 &nbsp &nbsp &nbsp &nbsp
		<input type="text" name="prov" size="30" placeholder="   Province"required>
		 Municipality
		<input type="text" name="mun" size="16" placeholder="   Municipality"required>
		 Barangay
		<input type="text" name="brgy" size="16" placeholder="   Barangay/Street"required>
		<hr><br>
		 Tel No./Cel No. (+63)
		<input type="tel" id="phone" name="cel" placeholder=" 912-345-6789" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
		 Email Address
		<input type="email" name="email" size="30" placeholder="   email"required>
		<br><br><hr> <br> <br>
		 Name of Father
		 &nbsp &nbsp
		<input type="text" name="fat" size="30" placeholder="   Fathers Name"required>
		 Occupation
		 &nbsp
		<input type="text" name="oc1" size="30" placeholder="   Occupation(N/A if not applicable)">
		 Income Per Month
		<input type="number" name="inc1" size="30" placeholder=""required>
		<br>
		 Name of Mother
		 &nbsp &nbsp
		<input type="text" name="mot" size="30" placeholder="   Mothers Name"required>
		 Occupation
		<input type="text" name="oc2" size="30" placeholder="   Occupation(N/A if not applicable)">
		 Income Per Month
		<input type="number" name="inc2" size="30" placeholder=""required>
		<br>
		 Name of Guardian
		<input type="text" name="gua" size="30" placeholder="   Guardians Name">
		 Relation
		 &nbsp &nbsp &nbsp
		<input type="text" name="rel" size="30" placeholder="">
		 Income Per Month
		<input type="number" name="inc3" size="30" placeholder="">
		<br><br><hr><br>
		 Tel/Cel No. (Parent/Guardian) (+63)
		<input type="tel" id="phone" name="cel1" placeholder=" 912-345-6789" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
		 Annual Family Gross Income
		<input type="number" name="afgi" size="30" placeholder=""required>
		<br><br><br>
		</div>
		<div class="footer__container">
			<div class="footer__card--1">
				<p>
				<p>
					____________________________________________________________
				</p>
					Signature over Printed Name of President/Treasure/Manager Date of Application <br>
					(indicate title/position)
				</p>
			</div>
			<div class="footer__card--2">
				<p>
				<p>
					______________________________________________
				</p>
				Date of Application
			</p>
			</div>
</div>
			<div class="savereset__container">
				<input type="submit" name="submit" value="SUBMIT">
				<input type="Reset" name="clear" Value="RESET">
			</div>
	</form>
	</div>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>


</body>
</html>
