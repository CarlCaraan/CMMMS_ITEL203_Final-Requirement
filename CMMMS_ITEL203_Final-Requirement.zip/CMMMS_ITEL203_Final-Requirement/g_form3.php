<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Application for Postal Id Card</title>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="css/g_form3.css?v=<?php echo time(); ?>">
</head>
<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	display: inline-block;
	border: 1px solid #000;
	border-radius: 2px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>

<body>

<!--header navbar-->
<?php
include_once 'header2.php';
?>
<!--continuation-->
                    <a href='g_form2.php' class="button" id="login-page"><i class="material-icons">&#xe5cb;</i>previous</a>
                </li>
                <li class="navbar__btn">
                    <a href='g_form4.php' class="button" id="login-page"><i class="material-icons">&#xe409;</i>next</a>
                </li>
                <li class="navbar__btn">
                    <a href='crud_g_form3.php' class="button" id="login-page"><i class="fas fa-database" style="margin-right:2px"></i>manage</a>
                </li>
            </ul>
        </div>
    </nav>
<br>
<?php
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$pid=$_POST['pid'];
	$rev=$_POST['rev'];
	$acn=$_POST['acn'];
	$poc=$_POST['poc'];
	$pon=$_POST['pon'];
	$orno=$_POST['orno'];
	$ordate=$_POST['ordate'];
	$prn=$_POST['prn'];
	$purpose=$_POST['purpose'];
	$optional=$_POST['optional'];
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$lname=$_POST['lname'];
	$suffix=$_POST['suffix'];
	$gender=$_POST['gender'];
	$dob=$_POST['dob'];
	$pob=$_POST['pob'];
	$prov=$_POST['prov'];
	$country=$_POST['country'];

  $sql = "INSERT INTO `postal`(`pid`,`rev`,`acn`,`poc`,`pon`,`orno`,`ordate`,`prn`,`purpose`,`optional`,
          `fname`,`mname`,`lname`,`suffix`,`gender`,`dob`,`pob`,`prov`,`country`)
        VALUES('$pid','$rev','$acn','$poc','$pon','$orno','$ordate','$prn','$purpose','$optional',
          '$fname','$mname','$lname','$suffix','$gender','$dob','$pob','$prov','$country')";
	echo "<script>alert('Wow! User Registration Completed.')</script>";
}

 ?>

  <!--header-->
<div class="form__container">
  <div class="header__container">
    <div class="header__card--1">

      <div class="header-inside__container--1">
  <img src="img\logo3.png" alt="logo" width="300" height="70" style="justify-content:center">
      <p style="justify-content:center"><b>PURPOSE APPLICATION FOR POSTAL ID CARDAPPLICANT’S</b></p>
      </div>

      <div class="header-inside__container--2">
        <p style="font-size: 20px">
          Republic of the Philippines<br>
        <b> PHILIPPINE POSTAL CORPORATION</b> <br>
        <p style="font-size: 10px;font-family: sans-serif">PLEASE READ THE GENERAL TERMS AND CONDITIONS AT THE BACK BEFORE ACCOMPLISHINGTHIS <br>
           FORM. PRINT ALL INFORMATION IN <b>CAPITAL LETTERS</b> AND <b>USE BLACK INK ONLY</b>.</p>
        </p>
      </div>
    </div>

    <div class="header__card--2">
<div class="header-upperleft__container" style="border: 1px solid black; align: right; padding: 10px; width: 270px">
  <!--form-->
<form method="post">
    PID Form No.
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="text" name="pid" size="10"required> <br>
    Revision (No.) (Date)
    &nbsp &nbsp
		<input type="date" name="rev" placholder ="" size ="30"required> <br>
    Application Control No:
		<input type="text" name="acn" size="10"required> <br>
    Accepting Post Office Code:
    &nbsp
		<input type="text" name="poc" size="5"required> <br>
    Accepting Post Office Name:
		<input type="text" name="pon" size="5"required> <br>
    <b>Or No.</b>
		<input type="text" name="orno" size="3"required>
    &nbsp &nbsp &nbsp &nbsp
    <br><b>Or Date.</b>
		<input type="date" name="ordate" placholder =""required> <br>
    <hr>
    <b>Postal Reference No.</b>
    &nbsp &nbsp
		<input type="text" name="prn" size="10"required> <br>
</div>
<br>
    </div>
  </div>
  <hr><br><br>
  <p style="text-align: center"><b>REPLACEMENT PART I - TO BE FILLED OUT BY THE APPLICANT</b></p>
  <br><br><hr><br>
  <p style="text-align: center"><b>A. APPLICATION TYPE</b></p>
  <br><hr>
  &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp<b>Purpose</b>&nbsp &nbsp &nbsp
				<input type="radio" name="purpose" value ="Initial"><b>Initial</b><br>
        &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp
         &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
         &nbsp &nbsp
				<input type="radio" name="purpose" value ="Renewal"><b>Renewal</b><br>
        &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp
        &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp&nbsp &nbsp &nbsp
				<input type="radio" name="purpose" value ="Card Replacement"><b>Card Replacement</b><br/><br/>
        <div class="checkbox__container" style="align:center; text-align:center; justify-content:center">
        <input type="radio" name="optional" value ="None"> None
				<input type="radio" name="optional" value ="Amendment of Name">Amendment of Name
				<input type="radio" name="optional" value ="Replacement of Lost Card">Replacement of Lost Card
				<input type="radio" name="optional" value ="Amendment of Biographic Data">Amendment of Biographic Data
				<input type="radio" name="optional" value ="Amendment of Authenticating Finger">Amendment of Authenticating Finger
				<input type="radio" name="optional" value ="Replacement of Damage Card"> Replacement of Damage Card
        </div>
        <hr><br>
  <p style="text-align: center"><b>B. APPLICATION DETAILS</b></p>
  <br><hr>
  <!--Table-->
    <table style="width:100%; border: 1px solid black;border-collapse: collapse">

  <tr>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">APPLICANT'S NAME <br><input type="text" name="fname" size="20"placeholder="   First Name"required> <br>
</th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">MIDDLE NAME <br><input type="text" name="mname" size="20"placeholder="   Middle Name"required> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">LAST NAME <br><input type="text" name="lname" size="20"placeholder="   Last Name"required> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">SUFFIX <br><input type="text" name="suffix" size="20"placeholder="   Suffix"required> <br></th>
  </tr>
  </table>
    <table style="width:100%; border: 1px solid black;border-collapse: collapse">

  <tr>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">GENDER <br>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <select name="gender" id=""required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <br>
</th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">DATE OF BIRTH  <br><input type="date" name="dob" placholder ="" size ="15"required> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">PLACE OF BIRTH  <br><input type="text" name="pob" size="20"placeholder="   City/Municipality"required> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">PROVINCE <br><input type="text" name="prov" size="20"placeholder="   Province"required> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">COUNTRY <br><input type="text" name="country" size="20"placeholder="   Country"required> <br></th>
  </tr>
  </table>
  <!--footer-->
      <!--save reset-->
      <div class="savereset__container">
				<input type="submit" name="submit" value="SUBMIT">
				<input type="Reset" name="clear" Value="RESET">
			</div>

</form>

</div>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>

</body>
</html>
