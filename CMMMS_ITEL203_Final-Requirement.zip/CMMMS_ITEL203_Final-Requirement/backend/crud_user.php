<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$username=$_POST['username'];
		$email=$_POST['email'];
		#$password=$_POST['password'];
	  $password = md5($_POST['password']);
		$sql = "INSERT INTO `users`( `username`, `email`,`password`)
		VALUES ('$username','$email','$password')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$username=$_POST['username'];
		$email=$_POST['email'];
		#$password=$_POST['password'];
	  $password = md5($_POST['password']);
		$sql = "UPDATE `users` SET `username`='$username',`email`='$email',`password`='$password' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `users` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM users WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
