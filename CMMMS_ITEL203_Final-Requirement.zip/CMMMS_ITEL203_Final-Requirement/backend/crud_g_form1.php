<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
		$name=$_POST['name'];
		$slot=$_POST['slot'];
		$age=$_POST['age'];
		$sex=$_POST['sex'];
		$status=$_POST['status'];
		$religion=$_POST['religion'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$resadd=$_POST['resadd'];
		$prov=$_POST['prov'];
		$mun=$_POST['mun'];
		$brgy=$_POST['brgy'];
		$cel=$_POST['cel'];
		$email=$_POST['email'];
		$fat=$_POST['fat'];
		$oc1=$_POST['oc1'];
		$inc1=$_POST['inc1'];
		$mot=$_POST['mot'];
		$oc2=$_POST['oc2'];
		$inc2=$_POST['inc2'];
		$gua=$_POST['gua'];
		$rel=$_POST['rel'];
		$inc3=$_POST['inc3'];
		$cel1=$_POST['cel1'];
		$afgi=$_POST['afgi'];

	$sql = "INSERT INTO `iskolaguna`(`name`,`slot`,`age`,`sex`,`status`,`religion`,`dob`,`pob`,`resadd`,`prov`,`mun`,`brgy`,`cel`,
		`email`,`fat`,`oc1`,`inc1`,`mot`,`oc2`,`inc2`,`gua`,`rel`,`inc3`,`cel1`,`afgi`)
	 VALUES('$name','$slot','$age','$sex','$status','$religion','$dob','$pob','$resadd',
		 '$prov','$mun','$brgy','$cel','$email','$fat','$oc1','$inc1','$mot','$oc2','$inc2','$gua','$rel','$inc3','$cel1','$afgi')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$name=$_POST['name'];
		$slot=$_POST['slot'];
		$age=$_POST['age'];
		$sex=$_POST['sex'];
		$status=$_POST['status'];
		$religion=$_POST['religion'];
		$dob=$_POST['dob'];
		$pob=$_POST['pob'];
		$resadd=$_POST['resadd'];
		$prov=$_POST['prov'];
		$mun=$_POST['mun'];
		$brgy=$_POST['brgy'];
		$cel=$_POST['cel'];
		$email=$_POST['email'];
		$fat=$_POST['fat'];
		$oc1=$_POST['oc1'];
		$inc1=$_POST['inc1'];
		$mot=$_POST['mot'];
		$oc2=$_POST['oc2'];
		$inc2=$_POST['inc2'];
		$gua=$_POST['gua'];
		$rel=$_POST['rel'];
		$inc3=$_POST['inc3'];
		$cel1=$_POST['cel1'];
		$afgi=$_POST['afgi'];

		$sql = "UPDATE `iskolaguna` SET `name`='$name',`slot`='$slot',`age`='$age',`sex`='$sex',`status`='$status',`religion`='$religion',
		`dob`='$dob',`pob`='$pob',`resadd`='$resadd',`prov`='$prov',
		`mun`='$mun',`brgy`='$brgy',`cel`='$cel',`email`='$email',`fat`='$fat',`oc1`='$oc1',`inc1`='$inc1',`mot`='$mot',`oc2`='$oc2',`inc2`='$inc2',`gua`='$gua',`rel`='$rel',
		`inc3`='$inc3',`cel1`='$cel1',`afgi`='$afgi' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `iskolaguna` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM iskolaguna WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
