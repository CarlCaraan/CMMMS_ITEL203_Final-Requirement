<?php
include 'database.php';

if(count($_POST)>0){
	if($_POST['type']==1){
  	$tin=$_POST['tin'];
  	$rdo=$_POST['rdo'];
  	$name=$_POST['name'];
  	$zip=$_POST['zip'];
  	$phone=$_POST['phone'];
  	$taxpayer=$_POST['taxpayer'];
  	$pcic=$_POST['pcic'];
  	$pname=$_POST['pname'];
  	$plocation=$_POST['plocation'];
  	$pnumber=$_POST['pnumber'];
  	$dawarded=$_POST['dawarded'];
  	$dcompleted=$_POST['dcompleted'];
  	$dacp=$_POST['dacp'];
  	$dccp=$_POST['dccp'];
  	$dapbc=$_POST['dapbc'];
  	$dcpbc=$_POST['dcpbc'];
  	$davat=$_POST['davat'];
  	$dcvat=$_POST['dcvat'];
  	$dacwt=$_POST['dacwt'];
  	$dccwt=$_POST['dccwt'];
  	$datapt=$_POST['datapt'];
  	$dctapt=$_POST['dctapt'];
  	$dacfp=$_POST['dacfp'];
  	$dccfp=$_POST['dccfp'];

	$sql = "INSERT INTO `contract`(`tin`,`rdo`,`name`,`zip`,`phone`,`taxpayer`,`pcic`,`pname`,`plocation`,`pnumber`,`dawarded`,`dcompleted`,`dacp`,
		`dccp`,`dapbc`,`dcpbc`,`davat`,`dcvat`,`dacwt`,`dccwt`,`datapt`,`dctapt`,`dacfp`,`dccfp`)
	 VALUES('$tin','$rdo','$name','$zip','$phone','$taxpayer','$pcic','$pname','$plocation',
		 '$pnumber','$dawarded','$dcompleted','$dacp','$dccp','$dapbc','$dcpbc','$davat','$dcvat','$dacwt','$dccwt','$datapt','$dctapt','$dacfp','$dccfp')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
  	$tin=$_POST['tin'];
  	$rdo=$_POST['rdo'];
  	$name=$_POST['name'];
  	$zip=$_POST['zip'];
  	$phone=$_POST['phone'];
  	$taxpayer=$_POST['taxpayer'];
  	$pcic=$_POST['pcic'];
  	$pname=$_POST['pname'];
  	$plocation=$_POST['plocation'];
  	$pnumber=$_POST['pnumber'];
  	$dawarded=$_POST['dawarded'];
  	$dcompleted=$_POST['dcompleted'];
  	$dacp=$_POST['dacp'];
  	$dccp=$_POST['dccp'];
  	$dapbc=$_POST['dapbc'];
  	$dcpbc=$_POST['dcpbc'];
  	$davat=$_POST['davat'];
  	$dcvat=$_POST['dcvat'];
  	$dacwt=$_POST['dacwt'];
  	$dccwt=$_POST['dccwt'];
  	$datapt=$_POST['datapt'];
  	$dctapt=$_POST['dctapt'];
  	$dacfp=$_POST['dacfp'];
  	$dccfp=$_POST['dccfp'];

		$sql = "UPDATE `contract` SET `tin`='$tin',`rdo`='$rdo',`name`='$name',`zip`='$zip',`phone`='$phone',`taxpayer`='$taxpayer',
		`pcic`='$pcic',`pname`='$pname',`plocation`='$plocation',`pnumber`='$pnumber',
		`dawarded`='$dawarded',`dcompleted`='$dcompleted',`dacp`='$dacp',`dccp`='$dccp',`dapbc`='$dapbc',`dcpbc`='$dcpbc',`davat`='$davat',`dcvat`='$dcvat',`dacwt`='$dacwt',`dccwt`='$dccwt',`datapt`='$datapt',`dctapt`='$dctapt',
		`dacfp`='$dacfp',`dccfp`='$dccfp' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `contract` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM contract WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
