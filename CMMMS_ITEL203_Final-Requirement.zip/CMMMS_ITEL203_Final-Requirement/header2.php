  <!--header2-->
<style>
*{
box-sizing: border-box;
padding: 0;
margin: 0;
font-family: 'kumbh Sans', sans-serif;
scroll-behavior: smooth;
}
.navbar__btn {
display: flex;
justify-content: center;
align-items: center;
padding: 0 1rem;
width: 100%;
}
.button {
display: flex;
align-items: center;
justify-content: center;
text-decoration: none;
padding: 10px 20px;
height: 30px;
width: 100%;
border: none;
outline: none;
border-radius: 4px;
background: #7F7FD5; /*button color Gradient www.uigradient.com */
background: -webkit-linear-gradient(to right, #FD4556, #56558e, #9696B0);
background: linear-gradient(to right, #FD4556, #56558e, #9999AD);
color: black;
transition: all 0.3s ease;
}
.button:hover{
color: white;
}
.navbar{
background: #0F1821;
height: 40px;
display: flex;
align-items: center;
justify-content: center;
font-size: 1.2rem;
position: sticky;
top: 0;
z-index: 999;
}
.navbar__container{ /*div*/
display: flex;
justify-content: space-between;
height: 80px;
z-index: 1;
width: 100%;
max-width: 1300px;
margin: 0 auto;
padding: 0 50px;
}
.navbar__menu{
display: flex;
align-items: center;
list-style: none;
}
#navbar__logo{
   background-color: white;
   background-image: linear-gradient(to top, white 0%, cyan 100%);
   background-size: 100%;
   -webkit-background-clip: text; /*remove background*/
   -moz-background-clip: text;
   -webkit-text-fill-color: transparent;
   display: flex;
   align-items: center;
   cursor: pointer;
   text-decoration: none;
   font-size: 2rem;
   width: 80%;
 }
</style>
	<!--navbar-->
    <nav class="navbar">
        <div class="navbar__container">
            <a href="#home" id="navbar__logo"><img src="img/logo.png" style="width:175px; height:200px;"></a>
            <ul class="navbar__menu">
                <li class="navbar__btn">
                    <a href='home.php' class="button" id="login-page"><i class="material-icons">&#xe88a;</i>back</a>
                </li>
                <li class="navbar__btn">
<!--previous and next here-->
