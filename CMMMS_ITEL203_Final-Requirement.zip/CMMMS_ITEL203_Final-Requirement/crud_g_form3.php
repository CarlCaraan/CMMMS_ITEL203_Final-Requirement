<?php
include 'backend/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manage - Application for Postal Id Card</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/crud_user.css?v=<?php echo time(); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="ajax/ajax3.js"></script>
</head>

<body>

		<!--table-->
    <div class="container">
	<p id="success"></p>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Records</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="logout.php" type="button" class="btn btn-danger" id="logout_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe9ba;</i>Logout</a>
						<a href="g_form3.php" type="button" class="btn btn-danger" id="back_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe85d;</i>back</a>
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xe7fe;</i> <span>Add Records</span></a>
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons">&#xef66;</i> <span>Delete</span></a>
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th>
        <th>ID</th>
          <th>PID FORM no.</th>
          <th>Revision (No.)(Date).</th>
          <th>Application Control No:</th>
          <th>Accepting Post Office Code:</th>
          <th>Accepting Post Office Name:</th>
          <th>OR No.</th>
          <th>OR Date</th>
          <th>Postal Reference No. </th>
          <th>Purpose</th>
          <th>Optional</th>
          <th>First Name</th>
          <th>Middle Name</th>
          <th>Last Name</th>
          <th>Suffix</th>
          <th>Gender</th>
          <th>DATE OF BIRTH</th>
          <th>PLACE OF BIRTH</th>
          <th>PROVINCE</th>
          <th>COUNTRY</th>
          <th>ACTION</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = mysqli_query( $conn, "SELECT * FROM postal" );
        $i = 1;
        while ( $row = mysqli_fetch_array( $result ) ) {
            ?>
        <tr id="<?php echo $row["id"]; ?>">
          <td><span class="custom-checkbox">
            <input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
            <label for="checkbox2"></label>
            </span></td>
          <td><?php echo $i; ?></td>
          <td><?php echo $row["pid"]; ?></td>
          <td><?php echo $row["rev"]; ?></td>
          <td><?php echo $row["acn"]; ?></td>
          <td><?php echo $row["poc"]; ?></td>
          <td><?php echo $row["pon"]; ?></td>
          <td><?php echo $row["orno"]; ?></td>
          <td><?php echo $row["ordate"]; ?></td>
          <td><?php echo $row["prn"]; ?></td>
          <td><?php echo $row["purpose"]; ?></td>
          <td><?php echo $row["optional"]; ?></td>
          <td><?php echo $row["fname"]; ?></td>
          <td><?php echo $row["mname"]; ?></td>
          <td><?php echo $row["lname"]; ?></td>
          <td><?php echo $row["suffix"]; ?></td>
          <td><?php echo $row["gender"]; ?></td>
          <td><?php echo $row["dob"]; ?></td>
          <td><?php echo $row["pob"]; ?></td>
          <td><?php echo $row["prov"]; ?></td>
          <td><?php echo $row["country"]; ?></td>
          <td>
            <a href="#editEmployeeModal" class="edit" data-toggle="modal">
             <i class="material-icons update" data-toggle="tooltip"
							data-id="<?php echo $row["id"]; ?>"
							data-pid="<?php echo $row["pid"]; ?>"
							data-rev="<?php echo $row["rev"]; ?>"
							data-acn="<?php echo $row["acn"]; ?>"
							data-poc="<?php echo $row["poc"]; ?>"
							data-pon="<?php echo $row["pon"]; ?>"
							data-orno="<?php echo $row["orno"]; ?>"
							data-ordate="<?php echo $row["ordate"]; ?>"
							data-prn="<?php echo $row["prn"]; ?>"
							data-purpose="<?php echo $row["purpose"]; ?>"
							data-optional="<?php echo $row["optional"]; ?>"
							data-fname="<?php echo $row["fname"]; ?>"
							data-mname="<?php echo $row["mname"]; ?>"
							data-lname="<?php echo $row["lname"]; ?>"
							data-suffix="<?php echo $row["suffix"]; ?>"
							data-gender="<?php echo $row["gender"]; ?>"
							data-dob="<?php echo $row["dob"]; ?>"
							data-pob="<?php echo $row["pob"]; ?>"
							data-prov="<?php echo $row["prov"]; ?>"
							data-country="<?php echo $row["country"]; ?>"
							title="Edit">&#xE254;</i>
             </a>
             <a href="#deleteEmployeeModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
						 title="Delete">&#xE872;</i></a>
           </td>
        </tr>
        <?php
        $i++;
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
<!-- Add Modal HTML -->
<div id="addEmployeeModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="user_form">
        <div class="modal-header">
          <h4 class="modal-title">Add Records</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>PID Form No.</label>
            <input type="text" id="pid" name="pid" class="form-control" required>
          </div>
          <div class="form-group">
            <label> Revision (No.) (Date)</label>
            <input type="date" id="rev" name="rev" class="form-control" required>
          </div>
    			<div class="form-group">
            <label> Application Control No.</label>
            <input type="text" id="acn" name="acn" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Accepting Post Office Code:</label>
            <input type="text" id="poc" name="poc" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Accepting Post Office Name:</label>
            <input type="text" id="pon" name="pon" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Or No.</label>
            <input type="text" id="orno" name="orno" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Or Date.</label>
            <input type="date" id="ordate" name="ordate" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Postal Reference No.</label>
            <input type="text" id="prn" name="prn" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Purpose</label>
            <select name="purpose" id="purpose" class="form-control"required>
              <option value="Initial">Initial</option>
              <option value="Renewal">Renewal</option>
              <option value="Card Replacement">Card Replacement</option>
            </select>
          </div>
          <div class="form-group">
            <label>Additional</label>
            <select name="optional" id="optional" class="form-control" required>
              <option value="None">None</option>
              <option value="Amendment of Name">Amendment of Name</option>
              <option value="Replacement of Lost Card">Replacement of Lost Card</option>
              <option value="Amendment of Biographic Data">Amendment of Biographic Data</option>
              <option value="Amendment of Authenticating Finger">Amendment of Authenticating Finger</option>
              <option value="Replacement of Damage Card">Replacement of Damage Card</option>
            </select>
          </div>
          <div class="form-group">
            <label>APPLICANT'S NAME</label>
            <input type="text" id="fname" name="fname" class="form-control" placeholder="first name" required>
          </div>
          <div class="form-group">
            <label>MIDDLE NAME</label>
            <input type="text" id="mname" name="mname" class="form-control" placeholder="middle name"required>
          </div>
          <div class="form-group">
            <label>LAST NAME</label>
            <input type="text" id="lname" name="lname" class="form-control" placeholder="last name"required>
          </div>
          <div class="form-group">
            <label>SUFFIX</label>
            <input type="text" id="suffix" name="suffix" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Gender</label>
            <select name="gender" id="gender"class="form-control"required>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="form-group">
            <label>DATE OF BIRTH</label>
            <input type="date" id="dob" name="dob" class="form-control" required>
          </div>
          <div class="form-group">
            <label>PLACE OF BIRTH</label>
            <input type="text" id="pob" name="pob" class="form-control" required>
          </div>
          <div class="form-group">
            <label>PROVINCE</label>
            <input type="text" id="prov" name="prov" class="form-control" required>
          </div>
          <div class="form-group">
            <label>COUNTRY</label>
            <input type="text" id="country" name="country" class="form-control" required>
						</div>
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<!-- Edit Modal HTML -->
<div id="editEmployeeModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="update_form">
        <div class="modal-header">
          <h4 class="modal-title">Edit User</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="id_u" name="id" class="form-control" required>
          <div class="form-group">
            <label>PID Form No.</label>
            <input type="text" id="pid_u" name="pid" class="form-control" required>
          </div>
          <div class="form-group">
            <label> Revision (No.) (Date)</label>
            <input type="date" id="rev_u" name="rev" class="form-control" required>
          </div>
    			<div class="form-group">
            <label> Application Control No.</label>
            <input type="text" id="acn_u" name="acn" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Accepting Post Office Code:</label>
            <input type="text" id="poc_u" name="poc" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Accepting Post Office Name:</label>
            <input type="text" id="pon_u" name="pon" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Or No.</label>
            <input type="text" id="orno_u" name="orno" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Or Date.</label>
            <input type="date" id="ordate_u" name="ordate" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Postal Reference No.</label>
            <input type="text" id="prn_u" name="prn" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Purpose</label>
            <select name="purpose" id="purpose_u"class="form-control"required>
              <option value="Initial">Initial</option>
              <option value="Renewal">Renewal</option>
              <option value="Card Replacement">Card Replacement</option>
            </select>
          </div>
          <div class="form-group">
            <label>Additional</label>
            <select name="optional" id="optional_u" class="form-control" required>
              <option value="None">None</option>
              <option value="Amendment of Name">Amendment of Name</option>
              <option value="Replacement of Lost Card">Replacement of Lost Card</option>
              <option value="Amendment of Biographic Data">Amendment of Biographic Data</option>
              <option value="Amendment of Authenticating Finger">Amendment of Authenticating Finger</option>
              <option value="Replacement of Damage Card">Replacement of Damage Card</option>
            </select>
          </div>
          <div class="form-group">
            <label>APPLICANT'S NAME</label>
            <input type="text" id="fname_u" name="fname" class="form-control" placeholder="first name" required>
          </div>
          <div class="form-group">
            <label>MIDDLE NAME</label>
            <input type="text" id="mname_u" name="mname" class="form-control" placeholder="middle name"required>
          </div>
          <div class="form-group">
            <label>LAST NAME</label>
            <input type="text" id="lname_u" name="lname" class="form-control" placeholder="last name"required>
          </div>
          <div class="form-group">
            <label>SUFFIX</label>
            <input type="text" id="suffix_u" name="suffix" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Gender</label>
            <select name="gender" id="gender_u"class="form-control"required>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="form-group">
            <label>DATE OF BIRTH</label>
            <input type="date" id="dob_u" name="dob" class="form-control" required>
          </div>
          <div class="form-group">
            <label>PLACE OF BIRTH</label>
            <input type="text" id="pob_u" name="pob" class="form-control" required>
          </div>
          <div class="form-group">
            <label>PROVINCE</label>
            <input type="text" id="prov_u" name="prov" class="form-control" required>
          </div>
          <div class="form-group">
            <label>COUNTRY</label>
            <input type="text" id="country_u" name="country" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <input type="hidden" value="2" name="type">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-info" id="update">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Delete Modal HTML -->
<div id="deleteEmployeeModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form>
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="id_d" name="id" class="form-control">
          <p>Are you sure you want to delete these Records?</p>
          <p class="text-warning"><small>This action cannot be undone.</small></p>
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-danger" id="delete">Delete</button>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
