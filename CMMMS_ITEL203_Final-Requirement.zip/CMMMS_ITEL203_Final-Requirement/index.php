<?php

?>

<html>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CMMMS</title>
<link rel="stylesheet" href="css/index.css?v=<?php echo time(); ?>">

<body>
<section>
    <header>
        <a href="#"><img src="img/index_logo.png" class="logo"></a>
    <ul>
        <li><a href="login.php"> Login</a></li>
        <li><a href="register.php"> Register</a></li>
    </ul>
    </header>
    <div class="content">
        <div class="txtBox">
        <h1>ITEL203 - Web Systems & Technologies</h1>
        <h2><b>Make it a</b><br><span><b>Simple Design</b></span></h2>
        <p>This website serves as a requirement to complete our finals project and uses for educational purposes only.</p>
        </div>
    </div>
</section>
</body>

</html>
