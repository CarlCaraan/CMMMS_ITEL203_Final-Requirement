<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Application for Contractor’s Final Payment Release Certificate</title>
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 <link rel="stylesheet" href="css/g_form2.css?v=<?php echo time(); ?>">
</head>
<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=tel], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=date], select {
	padding: 6px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #000;
	border-radius: 4px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>

<body>

<!--header navbar-->
<?php
include_once 'header2.php';
?>
<!--continuation-->
                    <a href='g_form1.php' class="button" id="login-page"><i class="material-icons">&#xe5cb;</i>previous</a>
                </li>
                <li class="navbar__btn">
                    <a href='g_form3.php' class="button" id="login-page"><i class="material-icons">&#xe409;</i>next</a>
                </li>
                <li class="navbar__btn">
                    <a href='crud_g_form2.php' class="button" id="login-page"><i class="fas fa-database" style="margin-right:2px"></i>manage</a>
                </li>
            </ul>
        </div>
    </nav>
<br>
<!--insert-->
<?php
include 'config.php';

error_reporting(0);

session_start();

if (isset($_POST['submit'])) {
	$tin=$_POST['tin'];
	$rdo=$_POST['rdo'];
	$name=$_POST['name'];
	$zip=$_POST['zip'];
	$phone=$_POST['phone'];
	$taxpayer=$_POST['taxpayer'];
	$pcic=$_POST['pcic'];
	$pname=$_POST['pname'];
	$plocation=$_POST['plocation'];
	$pnumber=$_POST['pnumber'];
	$dawarded=$_POST['dawarded'];
	$dcompleted=$_POST['dcompleted'];
	$dacp=$_POST['dacp'];
	$dccp=$_POST['dccp'];
	$dapbc=$_POST['dapbc'];
	$dcpbc=$_POST['dcpbc'];
	$davat=$_POST['davat'];
	$dcvat=$_POST['dcvat'];
	$dacwt=$_POST['dacwt'];
	$dccwt=$_POST['dccwt'];
	$datapt=$_POST['datapt'];
	$dctapt=$_POST['dctapt'];
	$dacfp=$_POST['dacfp'];
	$dccfp=$_POST['dccfp'];
	$sql = "INSERT INTO contract (tin,rdo,name,zip,phone,taxpayer,pcic,pname,plocation,pnumber,
		dawarded,dcompleted,dacp,dccp,dapbc,dcpbc,davat,dcvat,dacwt,dccwt,datapt,dctapt,dacfp,dccfp)
	VALUES ('$tin','$rdo','$name','$zip','$phone','$taxpayer','$pcic','$pname','$plocation','$pnumber',
		'$dawarded','$dcompleted','$dacp','$dccp','$dapbc','$dcpbc','$davat','$dcvat','$dacwt','$dccwt','$datapt','$dctapt','$dacfp','$dccfp')";
		$result = mysqli_query($conn, $sql);
	echo "<script>alert('Wow! User Registration Completed.')</script>";
}

 ?>

	<!--form-->
	<div class="form__container">
		<!--Header-->
<div class="header__wrapper">
<div class="header__card--1">
	<p><img src="img\logo1.png" alt="logo" width="85" height="70" style="justify-content:center"></p>
</div>
<div class="header__card--2">
	<p><b>Republic of the Philippines <br>
Department of Finance <br>
Bureau of Internal Revenue</b></p>
<p style="font-size: 12px; padding: 0">Read instructions at the back of this form before accomplishing</p>
</div>
<div class="header__card--3">
	<p style="font-size: 20px"> <b>APPLICATION FOR CONTRACTOR’S FINAL <br>
PAYMENT RELEASE CERTIFICATE</b></p><p style="font-size: 12px">Enter all required information in CAPITAL LETTERS using BLACK ink.
Mark all applicable boxes with an “X”. Two copies must be filed with the BIR and one held by the taxpayer.</p>
</div>
<div class="header__card--4">
<p>BIR Form No. <br>
<b style="font-size: 30px">0217</b> <br>
November 2014 (ENCS)</p>
</div>
</div>
	<!--form-->
<div class="formsbackground__container">
	<form method="post"><br>
		<b>1</b> Taxpayer Identification Number (TIN):<input type="text" name="tin" size="100" placeholder="    TIN"required>
		 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		 <b>2</b> RDO Code:<input type="text" name="rdo" size="30"placeholder="   RDO Code "required> <br>
		 <hr>
		<b>3</b> Name of Taxpayer/Contractor (Last Name, First Name, Middle Name for Individual)/(Registered Name for Non-Individual)
		<input type="text" name="name" size="50"placeholder="   (format)"required> &nbsp &nbsp &nbsp
		<b>4A</b> ZIP Code
		<input type="text" name="zip" size="30"placeholder="    Zip Code"required> <br>
		<hr>
		<b>5</b> Contact Number (+63)
	  <input type="tel"  name="phone" placeholder=" 912-345-678"pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<b>6</b> Taxpayer Classification:


				<select name="taxpayer" id="taxpayer"class="form-control"required>
            <option value="Individual">Individual</option>
            <option value="Corporation">Corporation</option>
        </select>

		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp

	<b>7</b> PSIC
		<input type="text" name="pcic" size="30"placeholder="   PCIC"required>
		<hr><br>
		<p style="text-align: center"> <b>● ● ● PROJECT APPLIED FOR RELEASE OF FINAL PAYMENT ● ● ●</b></p>
		<br><hr>
		<b>8</b> Project Name
		&nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="text" name="pname" size="100"placeholder="   Project Name Here"required> <br>
		<hr>
		<b>9</b> Project Location
		&nbsp &nbsp &nbsp
		<input type="text" name="plocation" size="100"placeholder="   Project Location Here"required> <br>
		<hr><br>
		<b>10</b> Project ID Number
		<input type="text" name="pnumber" size="100"placeholder="   Project ID number Here"required>
		<b>11</b> Date Awarded (MM/DD/YYYY)
		<input type="date" name="dawarded" size="10"required>
		<b>12</b> Date Completed (MM/DD/YYYY)
		<input type="date" name="dcompleted" size="10"required> <br><br>

		<b>13</b> Total Contract Price
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dacp" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dccp" size="10"required> <br>
		<br>
		 <b>14</b> Progress Billings Collected
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dapbc" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dcpbc" size="10"required> <br>
		<br>
	<b>15</b> Final Withholding VAT (5%)
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="davat" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dcvat" size="10"required> <br>
		<br>
	<b>16</b> Creditable Withholding Tax (2%)
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dacwt" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dccwt" size="10"required> <br>
		<br>
	<b>17</b> Total Amount previously collected and taxes withheld
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp
		<input type="date" name="datapt" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dctapt" size="10"required> <br>
		<br>
	<b>18</b> Collectible Final Payment
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp
		<input type="date" name="dacfp" size="10"required>
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="date" name="dccfp" size="10"required> <br><br><br>
		</div>
		<!--footer-->
		<div class="footer__container">
			<div class="footer__card--1">
				<p>
				<p>
					____________________________________________________________
				</p>
					Signature over Printed Name of President/Treasure/Manager Date of Application <br>
					(indicate title/position)
				</p>
			</div>
			<div class="footer__card--2">
				<p>
				<p>
					______________________________________________
				</p>
				Date of Application
			</p>
			</div>
</div>
<!--submit button-->
			<div class="savereset__container">
				<input type="submit" name="submit" value="SUBMIT">
				<input type="Reset" name="clear" Value="RESET">
			</div>
	</form>
	</div>

<!--footer-->
<footer>
  <center>
    <div class="box__container">
      <div class="disclaimer__container">
      <strong class="txt1"><b>DISCLAIMER</b></strong>
      <p><i>This form is for personal use only. We will not make or sell any of these copy to anyone else.</i></p>
      </div>
    </div>
  </center>
</section>
<br></br>
</footer>

</body>
</html>
