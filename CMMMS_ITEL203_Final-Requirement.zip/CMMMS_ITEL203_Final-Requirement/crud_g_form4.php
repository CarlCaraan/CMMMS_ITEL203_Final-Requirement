<?php
include 'backend/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manage - Application for Birth Certificate</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/crud_user.css?v=<?php echo time(); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="ajax/ajax4.js"></script>
</head>

<body>

		<!--table-->
    <div class="container">
	<p id="success"></p>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Records</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="logout.php" type="button" class="btn btn-danger" id="logout_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe9ba;</i>Logout</a>
						<a href="g_form4.php" type="button" class="btn btn-danger" id="back_btn" style="text-align: right; background: gray" ><i class="material-icons">&#xe85d;</i>back</a>
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xe7fe;</i> <span>Add Records</span></a>
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons">&#xef66;</i> <span>Delete</span></a>
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th>
						<th>ID</th>
                        <th>Request for</th>
                        <th>No of Copies</th>
												<th>Others</th>
                        <th>Birth Reference No.</th>
												<th>Gender</th>
                        <th>Last Name</th>
                        <th>First Name</th>
												<th>Middle Name</th>
												<th>Date of Birth</th>
                        <th>Place of Birth</th>
												<th>Province</th>
                        <th>Country</th>
                        <th>Last Name(father)</th>
												<th>First Name(father)</th>
                        <th>Middle Name(father)</th>
                        <th>Last Name(mother)</th>
												<th>First Name(mother)</th>
                        <th>Middle Name(mother)</th>
												<th>Registered Late</th>
                        <th>When</th>
												<th>Requester's Tax Identification No.</th>
												<th>Transaction Number</th>
                        <th>Purpose</th>
                        <th>Specify Country</th>
												<th>Requester's Information(fullname)</th>
												<th>Mailing Address</th>
                        <th>City/Municipality</th>
                        <th>Province</th>
												<th>Telephone No./Contact No.</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
				<tbody>

				<?php
				$result = mysqli_query($conn,"SELECT * FROM birthcert");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					<td><?php echo $i; ?></td>
					<td><?php echo $row["req"]; ?></td>
					<td><?php echo $row["copies"]; ?></td>
					<td><?php echo $row["others"]; ?></td>
					<td><?php echo $row["brn"]; ?></td>
					<td><?php echo $row["gender"]; ?></td>
					<td><?php echo $row["lname"]; ?></td>
					<td><?php echo $row["fname"]; ?></td>
					<td><?php echo $row["mname"]; ?></td>
					<td><?php echo $row["dob"]; ?></td>
					<td><?php echo $row["pob"]; ?></td>
					<td><?php echo $row["prov"]; ?></td>
					<td><?php echo $row["country"]; ?></td>
					<td><?php echo $row["lnamef"]; ?></td>
					<td><?php echo $row["fnamef"]; ?></td>
					<td><?php echo $row["mnamef"]; ?></td>
					<td><?php echo $row["lnamem"]; ?></td>
					<td><?php echo $row["fnamem"]; ?></td>
					<td><?php echo $row["mnamem"]; ?></td>
					<td><?php echo $row["late"]; ?></td>
					<td><?php echo $row["when1"]; ?></td>
					<td><?php echo $row["tin"]; ?></td>
					<td><?php echo $row["tn"]; ?></td>
					<td><?php echo $row["extra"]; ?></td>
					<td><?php echo $row["specou"]; ?></td>
					<td><?php echo $row["rfull"]; ?></td>
					<td><?php echo $row["madd"]; ?></td>
					<td><?php echo $row["mcity"]; ?></td>
					<td><?php echo $row["mprov"]; ?></td>
					<td><?php echo $row["mpho"]; ?></td>
					<td>
						<a href="#editEmployeeModal" class="edit" data-toggle="modal">
							<i class="material-icons update" data-toggle="tooltip"
							data-id="<?php echo $row["id"]; ?>"
							data-req="<?php echo $row["req"]; ?>"
							data-copies="<?php echo $row["copies"]; ?>"
							data-others="<?php echo $row["others"]; ?>"
							data-brn="<?php echo $row["brn"]; ?>"
							data-gender="<?php echo $row["gender"]; ?>"
							data-lname="<?php echo $row["lname"]; ?>"
							data-fname="<?php echo $row["fname"]; ?>"
							data-mname="<?php echo $row["mname"]; ?>"
							data-dob="<?php echo $row["dob"]; ?>"
							data-pob="<?php echo $row["pob"]; ?>"
							data-prov="<?php echo $row["prov"]; ?>"
							data-country="<?php echo $row["country"]; ?>"
							data-lnamef="<?php echo $row["lnamef"]; ?>"
							data-fnamef="<?php echo $row["fnamef"]; ?>"
							data-mnamef="<?php echo $row["mnamef"]; ?>"
							data-lnamem="<?php echo $row["lnamem"]; ?>"
							data-fnamem="<?php echo $row["fnamem"]; ?>"
							data-mnamem="<?php echo $row["mnamem"]; ?>"
							data-late="<?php echo $row["late"]; ?>"
							data-when1="<?php echo $row["when1"]; ?>"
							data-tin="<?php echo $row["tin"]; ?>"
							data-tn="<?php echo $row["tn"]; ?>"
							data-extra="<?php echo $row["extra"]; ?>"
							data-specou="<?php echo $row["specou"]; ?>"
							data-rfull="<?php echo $row["rfull"]; ?>"
							data-madd="<?php echo $row["madd"]; ?>"
							data-mcity="<?php echo $row["mcity"]; ?>"
							data-mprov="<?php echo $row["mprov"]; ?>"
							data-mpho="<?php echo $row["mpho"]; ?>"
							title="Edit">&#xE254;</i>
						</a>
						<a href="#deleteEmployeeModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
						 title="Delete">&#xE872;</i></a>
                    </td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>

        </div>
    </div>
	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form">
					<div class="modal-header">
						<h4 class="modal-title">Add Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>Request for</label>
            <select name="req" id="req" class="form-control" required>
              <option value="Birth Certificate">Birth Certificate</option>
              <option value="Authentication">Authentication</option>
              <option value="Birth Card">Birth Card</option>
              <option value="CDLI">CDLI</option>
            </select>
						</div>
						<div class="form-group">
							<label>No of Copies</label>
            <select name="copies" id="copies" class="form-control" required>
              <option value="1">One</option>
              <option value="2">Two</option>
            </select>
						</div>
						<div class="form-group">
							<label>Others</label>
							<input type="text" id="others" name="others" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Birth Reference No.</label>
							<input type="text" id="brn" name="brn" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Gender</label>
            <select name="gender" id="gender" class="form-control" required>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
						</div>
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" id="lname" name="lname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>First Name</label>
							<input type="date" id="fname" name="fname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name</label>
							<input type="text" id="mname" name="mname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date of Birth</label>
							<input type="date" id="dob" name="dob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Place of Birth</label>
							<input type="text" id="pob" name="pob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="prov" name="prov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Country</label>
							<input type="text" id="country" name="country" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last Name(father)</label>
							<input type="text" id="lnamef" name="lnamef" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>First Name(father)</label>
							<input type="email" id="fnamef" name="fnamef" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name(father)</label>
							<input type="text" id="mnamef" name="mnamef" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last Name(mother)</label>
							<input type="text" id="lnamem" name="lnamem" class="form-control">
						</div>
						<div class="form-group">
							<label>First Name(mother)</label>
							<input type="text" id="fnamem" name="fnamem" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name(mother)</label>
							<input type="text" id="mnamem" name="mnamem" class="form-control">
						</div>
						<div class="form-group">
							<label>Registered Late</label>
            <select name="late" id="late" class="form-control" required>
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </select>
						</div>
						<div class="form-group">
							<label>When</label>
							<input type="date" id="when1" name="when1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Requester's Tax Identification No.</label>
							<input type="text" id="tin" name="tin" class="form-control">
						</div>
						<div class="form-group">
							<label>Transaction Number</label>
							<input type="text" id="tn" name="tn" class="form-control">
						</div>
						<div class="form-group">
							<label>Purpose</label>
            <select name="extra" id="extra" class="form-control" required>
              <option value="Claim Benefits/Loan">Claim Benefits/Loan</option>
              <option value="Passport/Travel">Passport/Travel</option>
              <option value="Employment Abroad">Employment Abroad</option>
              <option value="Employment Local">Employment Local</option>
              <option value="School Requirements">School Requirements</option>
              <option value="Others">Others</option>
            </select>
						</div>
						<div class="form-group">
							<label>Specify Country</label>
							<input type="text" id="specou" name="specou" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Requester's Information(fullname)</label>
							<input type="text" id="rfull" name="rfull" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Mailing Address</label>
							<input type="text" id="madd" name="madd" class="form-control" required>
						</div>
						<div class="form-group">
							<label>City/Municipality</label>
							<input type="text" id="mcity" name="mcity" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="mprov" name="mprov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Telephone No./Contact No.</label>
							<input type="tel" id="mpho" name="mpho" class="form-control"pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
						</div>
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="update_form">
					<div class="modal-header">
						<h4 class="modal-title">Edit Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_u" name="id" class="form-control" required>
						<div class="form-group">
							<label>Request for</label>
            <select name="req" id="req_u" class="form-control" required>
              <option value="Birth Certificate">Birth Certificate</option>
              <option value="Authentication">Authentication</option>
              <option value="Birth Card">Birth Card</option>
              <option value="CDLI">CDLI</option>
            </select>
						</div>
						<div class="form-group">
							<label>No of Copies</label>
            <select name="copies" id="copies_u" class="form-control" required>
              <option value="1">One</option>
              <option value="2">Two</option>
            </select>
						</div>
						<div class="form-group">
							<label>Others</label>
							<input type="text" id="others_u" name="others" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Birth Reference No.</label>
							<input type="text" id="brn_u" name="brn" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Gender</label>
            <select name="gender" id="gender_u" class="form-control" required>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
						</div>
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" id="lname_u" name="lname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>First Name</label>
							<input type="date" id="fname_u" name="fname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name</label>
							<input type="text" id="mname_u" name="mname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Date of Birth</label>
							<input type="date" id="dob_u" name="dob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Place of Birth</label>
							<input type="text" id="pob_u" name="pob" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="prov_u" name="prov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Country</label>
							<input type="text" id="country_u" name="country" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last Name(father)</label>
							<input type="text" id="lnamef_u" name="lnamef" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>First Name(father)</label>
							<input type="email" id="fnamef_u" name="fnamef" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name(father)</label>
							<input type="text" id="mnamef_u" name="mnamef" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last Name(mother)</label>
							<input type="text" id="lnamem_u" name="lnamem" class="form-control">
						</div>
						<div class="form-group">
							<label>First Name(mother)</label>
							<input type="text" id="fnamem_u" name="fnamem" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle Name(mother)</label>
							<input type="text" id="mnamem_u" name="mnamem" class="form-control">
						</div>
						<div class="form-group">
							<label>Registered Late</label>
            <select name="late" id="late_u" class="form-control" required>
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </select>
						</div>
						<div class="form-group">
							<label>When</label>
							<input type="date" id="when1_u" name="when1" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Requester's Tax Identification No.</label>
							<input type="text" id="tin_u" name="tin" class="form-control">
						</div>
						<div class="form-group">
							<label>Transaction Number</label>
							<input type="text" id="tn_u" name="tn" class="form-control">
						</div>
						<div class="form-group">
							<label>Purpose</label>
            <select name="extra" id="extra_u" class="form-control" required>
              <option value="Claim Benefits/Loan">Claim Benefits/Loan</option>
              <option value="Passport/Travel">Passport/Travel</option>
              <option value="Employment Abroad">Employment Abroad</option>
              <option value="Employment Local">Employment Local</option>
              <option value="School Requirements">School Requirements</option>
              <option value="Others">Others</option>
            </select>
						</div>
						<div class="form-group">
							<label>Specify Country</label>
							<input type="text" id="specou_u" name="specou" class="form-control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"required>
						</div>
						<div class="form-group">
							<label>Requester's Information(fullname)</label>
							<input type="text" id="rfull_u" name="rfull" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Mailing Address</label>
							<input type="text" id="madd_u" name="madd" class="form-control" required>
						</div>
						<div class="form-group">
							<label>City/Municipality</label>
							<input type="text" id="mcity_u" name="mcity" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="text" id="mprov_u" name="mprov" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Telephone No./Contact No.</label>
							<input type="tel" id="mpho_u" name="mpho" class="form-control"pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
						</div>

					</div>
					<div class="modal-footer">
					<input type="hidden" value="2" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-info" id="update">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>

					<div class="modal-header">
						<h4 class="modal-title">Delete Records</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_d" name="id" class="form-control">
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-danger" id="delete">Delete</button>
					</div>
				</form>
			</div>
		</div>
	</div>

</body>
</html>
