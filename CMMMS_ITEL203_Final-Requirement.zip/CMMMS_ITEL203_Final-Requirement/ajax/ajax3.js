<!-- Add user -->
	$(document).on('click','#btn-add',function(e) {
		var data = $("#user_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form3.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#addEmployeeModal').modal('hide');
						alert('Data added successfully !');
                        location.reload();
					} else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on('click','.update',function(e) {
		var id=$(this).attr("data-id");
		var pid=$(this).attr("data-pid");
		var rev=$(this).attr("data-rev");
		var acn=$(this).attr("data-acn");
		var poc=$(this).attr("data-poc");
		var pon=$(this).attr("data-pon");
		var orno=$(this).attr("data-orno");
		var ordate=$(this).attr("data-ordate");
		var prn=$(this).attr("data-prn");
		var purpose=$(this).attr("data-purpose");
		var optional=$(this).attr("data-optional");
		var fname=$(this).attr("data-fname");
		var mname=$(this).attr("data-mname");
		var lname=$(this).attr("data-lname");
		var suffix=$(this).attr("data-suffix");
		var gender=$(this).attr("data-gender");
		var dob=$(this).attr("data-dob");
		var pob=$(this).attr("data-pob");
		var prov=$(this).attr("data-prov");
		var country=$(this).attr("data-country");
		$('#id_u').val(id);
		$('#pid_u').val(pid);
		$('#rev_u').val(rev);
		$('#acn_u').val(acn);
		$('#poc_u').val(poc);
		$('#pon_u').val(pon);
		$('#orno_u').val(orno);
		$('#ordate_u').val(ordate);
		$('#prn_u').val(prn);
		$('#optional_u').val(optional);
		$('#fname_u').val(fname);
		$('#mname_u').val(mname);
		$('#lname_u').val(lname);
		$('#suffix_u').val(suffix);
		$('#gender_u').val(gender);
		$('#dob_u').val(dob);
		$('#pob_u').val(pob);
		$('#prov_u').val(prov);
		$('#country_u').val(country);
	});
<!-- Update -->
	$(document).on('click','#update',function(e) {
		var data = $("#update_form").serialize();
		$.ajax({
			data: data,
			type: "post",
			url: "backend/crud_g_form3.php",
			success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#editEmployeeModal').modal('hide');
						alert('Data updated successfully !');
                        location.reload();
					}
					else if(dataResult.statusCode==201){
					   alert(dataResult);
					}
			}
		});
	});
	$(document).on("click", ".delete", function() {
		var id=$(this).attr("data-id");
		$('#id_d').val(id);

	});
	$(document).on("click", "#delete", function() {
		$.ajax({
			url: "backend/crud_g_form3.php",
			type: "POST",
			cache: false,
			data:{
				type:3,
				id: $("#id_d").val()
			},
			success: function(dataResult){
					$('#deleteEmployeeModal').modal('hide');
					$("#"+dataResult).remove();

			}
		});
	});
	$(document).on("click", "#delete_multiple", function() {
		var user = [];
		$(".user_checkbox:checked").each(function() {
			user.push($(this).data('user-id'));
		});
		if(user.length <=0) {
			alert("Please select records.");
		}
		else {
			WRN_PROFILE_DELETE = "Are you sure you want to delete "+(user.length>1?"these":"this")+" row?";
			var checked = confirm(WRN_PROFILE_DELETE);
			if(checked == true) {
				var selected_values = user.join(",");
				console.log(selected_values);
				$.ajax({
					type: "POST",
					url: "backend/crud_g_form3.php",
					cache:false,
					data:{
						type: 4,
						id : selected_values
					},
					success: function(response) {
						var ids = response.split(",");
						for (var i=0; i < ids.length; i++ ) {
							$("#"+ids[i]).remove();
						}
					}
				});
			}
		}
	});
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip();
		var checkbox = $('table tbody input[type="checkbox"]');
		$("#selectAll").click(function(){
			if(this.checked){
				checkbox.each(function(){
					this.checked = true;
				});
			} else{
				checkbox.each(function(){
					this.checked = false;
				});
			}
		});
		checkbox.click(function(){
			if(!this.checked){
				$("#selectAll").prop("checked", false);
			}
		});
	});
